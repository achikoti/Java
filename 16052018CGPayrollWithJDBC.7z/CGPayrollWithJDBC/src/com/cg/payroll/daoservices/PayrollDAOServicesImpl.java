package com.cg.payroll.daoservices;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.utility.PayrollUtility;
public class PayrollDAOServicesImpl implements PayrollDAOServices{

	private Connection con=null;
	public  PayrollDAOServicesImpl() throws PayrollServicesDownException {
		con=PayrollUtility.getDBConnection();
	}
	@Override
	public int insertAssociate(Associate associate) throws SQLException {
		try {
			con.setAutoCommit(false);
			PreparedStatement pstmt1=con.prepareStatement("insert into Associate(firstName,lastName,emailId,department,designation,pancard,yearlyInvestmentUnder80C)values(?,?,?,?,?,?,?)");
			pstmt1.setString(1,associate.getFirstName());
			pstmt1.setString(2,associate.getLastName());
			pstmt1.setString(3,associate.getEmailId());
			pstmt1.setString(4,associate.getDepartment());
			pstmt1.setString(5,associate.getDesignation());
			pstmt1.setString(6,associate.getPancard());
			pstmt1.setInt(7,associate.getYearlyInvestmentUnder80C());
			pstmt1.executeUpdate();
			
			PreparedStatement pstmt2=con.prepareStatement("select max(associateID) from Associate");
			ResultSet rs=pstmt2.executeQuery();
			rs.next();
			int associateID=rs.getInt(1);
			
			PreparedStatement pstmt3=con.prepareStatement("insert into BankDetails(associateID,accountNumber,bankName,ifscCode)values(?,?,?,?)");
			pstmt3.setInt(1,associateID);
			pstmt3.setInt(2, associate.getBankdetails().getAccountNumber());
			pstmt3.setString(3, associate.getBankdetails().getBankName());
			pstmt3.setString(4, associate.getBankdetails().getIfscCode());
			pstmt3.executeUpdate();
			
			PreparedStatement pstmt4=con.prepareStatement("insert into Salary(associateID,basicSalary,epf,companyPf)values(?,?,?,?)");
			pstmt4.setInt(1,associateID);
			pstmt4.setInt(2, associate.getSalary().getBasicSalary());
			pstmt4.setInt(3, associate.getSalary().getEpf());
			pstmt4.setInt(4, associate.getSalary().getCompanyPf());
			pstmt4.executeUpdate();
			
			con.commit();
			return associateID;
			
		} catch (SQLException e) {
			con.rollback();
			throw e;
		}
		finally {
			con.setAutoCommit(true);
		}
	}
	@Override
	public boolean updateAssociate(Associate associate) {
	
		return false;
	}
	@Override
	public boolean deleteAssociate(int associateID) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public Associate getAssociate(int associateID) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<Associate> getAssociates() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
