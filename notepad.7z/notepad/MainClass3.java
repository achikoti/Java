public class MainClass3{
	public static void main(String[] str){
			for(int i=0;i<=5;i++){
			for(int j=1;j<=i+1;j++){
				System.out.print("*");
			}
			System.out.print("\n");
			}
	}
}