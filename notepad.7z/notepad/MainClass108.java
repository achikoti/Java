public class MainClass108{
	public static void main(String[] str){
		System.out.printf("\nBinary Search");
		int se=25,f,l,m;
		int []a={36,9,14,25};
		f = 0;
		l = a.length-1;
		m = (f+l)/2;
		while( f <= l ){
			if ( a[m] < se )
				f = m + 1;    
			else if ( a[m] == se ){
				System.out.printf("\n"+se+" found at location "+(m+1));
				break;
			}
			else
				l = m - 1;
 
			m = (f + l)/2;
		}
		if ( f > l )
			System.out.printf("\n Not found!"+se+" is not present in the array");
		System.out.printf("\nSequential Search");
		int p=0;
		for(int i=0;i<a.length;i++){
			if(se==a[i]){
				p=i+1;
				break;
			}
		}
		if(p!=0)
			System.out.printf("\n"+se+" found at location "+p);
		else
			System.out.printf("\n Not found!"+se+" is not present in the array");

	}
}