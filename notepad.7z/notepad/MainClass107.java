public class MainClass107{
	public static void main(String[] str){
		int a=10,b=15;
		System.out.print("Before Swapping: "+"a: "+a+" b: "+b);
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.print("\nAfter Swapping: "+"a: "+a+" b: "+b);
	}
}