public class MainClass113{
	public static void main(String[] str){
		int a[]={1,2,3,4,5,6,7,8,9},temp1,l=a.length-1,k;
		for(int i=0;i<a.length;i++){
			for(int j=i+1;j<a.length;j++){
				if(a[i]<a[j]){
					temp1=a[j];
					a[j]=a[i];
					a[i]=temp1;
				}
			}
		}
		for(int i=0;i<a.length;i++){
			if(i+1<a.length){
				if(a[i]>a[i+1]){
					temp1=a[l];
					k=l;
					while(k > i+1){
						a[k]=a[k-1];
						k--;
						
					}
					a[i+1]=temp1;
				}

			}
		}
		for(int i=0;i<a.length;i++){
			System.out.print(a[i]+" ");
		}
	}
}