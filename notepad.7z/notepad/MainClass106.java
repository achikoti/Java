public class MainClass106{
	public static void main(String[] str){
		System.out.print("Bubble Sort");
		int a[]={25,68,95,74,36},temp=0;
		for(int i=0;i<a.length;i++){
			for(int j=i+1;j<a.length;j++){
				if(a[i]>a[j]){
					temp=a[j];
					a[j]=a[i];
					a[i]=temp;
				}
			}
		}
		System.out.print("\n");
		for(int i=0;i<a.length;i++){
			System.out.print(a[i]+" ");
		}
		System.out.print("\n");
		System.out.print("Selection Sort");
		int []b={26,95,10,65,77};
		for(int i=0;i<b.length;i++){
			int k=b[i],l=i;
			for(int j=i+1;j<b.length;j++){
				if(k>b[j]){
					k=b[j];
					l=j;
				}
			}
			temp=b[i];
			b[i]=b[l];
			b[l]=temp;
		}
		System.out.print("\n");
		for(int i=0;i<b.length;i++){
			System.out.print(b[i]+" ");
		}
		is();
		
	}
	public static void is(){
		int[] arr={10,5,3,4,8,27};
		int temp,n,min,key;
		n=arr.length;
		for(int i=1;i<n;i++){
		System.out.println( i + "  " );
		key=arr[i];
		for(int j=i-1;j>=0;j--){
			if(arr[j]>key){
			arr[j+1]=arr[j];
			arr[j]=key;

}
}			
}
		for(int i=0;i<n;i++)
		System.out.print( arr[i] + "  " );		
}
}