public class MainClass105{
	public static void main(String[] str){
		int n=5,rem=0,b=0,i=1,dup=n,d=0;
		while(dup!=0){
			rem=dup%2;
			dup=dup/2;
			b=b+(rem*i);
			i=i*10;
		}
		System.out.print("The binary of "+n+" is "+b);
		int dup2=b;
		i=1;
		while(dup2!=0){
			rem= dup2%10;
			dup2=dup2/10;
			d=d+(rem*i) ;
			i=i*2;
		}
		System.out.print("\n");
		System.out.print("The decimal of "+b+" is "+d);
	}
}