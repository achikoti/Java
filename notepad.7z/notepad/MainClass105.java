public class MainClass105{
	public static void main(String[] str){
		
	}
}