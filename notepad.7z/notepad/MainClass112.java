public class MainClass112{
	public static void main(String[] str){
		int a[]={5,8,9,7,10},temp1,l=a.length;
		for(int i=0;i<a.length;i++){
			for(int j=i+1;j<a.length;j++){
				if(a[i]>a[j]){
					temp1=a[j];
					a[j]=a[i];
					a[i]=temp1;
				}
			}
		}
		int g3=l-3;
		System.out.print(a[g3]+"is the third largest number in the given range.");
	}
}