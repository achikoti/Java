public class MainClass111{
	public static void main(String[] str){
		int []a={1,2,3,4};
		for(int i=0;i<a.length;i++){
			if(a[i]%2 == 0)
				System.out.println(a[i]+"is an even number.");
			else
				System.out.println(a[i]+"is an odd number.");
		}
	}
}