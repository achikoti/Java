public class MainClass109{
	public static void main(String[] str){
		int a=1,b=2,c=1;
		double d=0,r1=0,r2=0;
		d=b*b-4*a*c;
		r1 = (-b + Math.sqrt(d))/(2*a);
                r2 = (-b - Math.sqrt(d))/(2*a);
		System.out.println(r1);
		System.out.println(r1);
		mm();
	}
	public static void mm(){
	int a[][]={{1,1,1},{2,2,2},{3,3,3}};    
		int b[][]={{1,1,1},{2,2,2},{3,3,3}};
		int c[][]=new int[3][3];
		for(int i=0;i<3;i++){    
			for(int j=0;j<3;j++){    
				c[i][j]=0;      
				for(int k=0;k<3;k++){      
					c[i][j]+=a[i][k]*b[k][j]; 
				}
				System.out.print(c[i][j]+" "); 
			}
			System.out.println();
		  }
		  }
}