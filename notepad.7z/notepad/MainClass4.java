public class MainClass4{
	public static void main(String[] str){
			for(int i=5;i>=1;i--){
			for(int j=i;j>=1;j--){
				System.out.print("*");
			}
			System.out.print("\n");
			}
	}
}