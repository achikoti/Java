public class MainClass122{
	public static void main(String[] str){
		int a,b,p=4,q=5,t,hcf,lcm;
		a=p;
		b=q;
		while(b != 0){
			t=b;
			b=a % b;
			a=t;
		}
		hcf = a;
		lcm = (p * q) / hcf;
		System.out.println("HCF = " + hcf);
		System.out.println("\nLCM = " + lcm);
}
}