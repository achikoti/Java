public class MainClass102{
	public static void main(String[] str){
		int org=153,sum=0,dup1=org,rem=0,count=0;
		while(dup1!=0){
			rem = dup1%10;
			sum = sum + (rem*rem*rem); 
			dup1 = dup1/10;
		}
		if(sum==org)
			System.out.println(org+" is a Armstrong number");
		else
			System.out.println(org+" is not a Armstrong number");
		
	}
}