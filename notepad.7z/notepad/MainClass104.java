public class MainClass104{
	public static void main(String[] str){
		int nd=10, a1=0, a2=1,a3=0;
		for(int i=1;i<=nd;i++){
			System.out.print(a1+" ");
			a3 = a1 + a2;
			a1 = a2;
			a2 = a3;
		}
	}
}