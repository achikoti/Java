package com.cg.project.beans;

public class Account {
	private int id;
	private float balance;
	private Customer customer;
	public Account() {
		super();
	}
	public Account(int id, float balance, Customer customer) {
		super();
		this.id = id;
		this.balance = balance;
		this.customer = customer;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
}
