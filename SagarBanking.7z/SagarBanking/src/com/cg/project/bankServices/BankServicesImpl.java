package com.cg.project.bankServices;

import com.cg.project.exception.AccountNotFoundException;

import com.cg.project.bankdaoServices.BankDAOServices;
import com.cg.project.bankdaoServices.BankDAOServicesImpl;
import com.cg.project.beans.Account;
import com.cg.project.exception.InsufficientAmountException;
import com.cg.project.exception.InvalidAmountException;
import com.cg.project.utility.BankUtility;

public class BankServicesImpl implements BankServices{
	BankDAOServices daoServices=new BankDAOServicesImpl();
	@Override
	public int createAccount(Account account) {
		return daoServices.insertAccount(account);
	}
	@Override
	public float showBalance(int accountNo) throws AccountNotFoundException {
		if(daoServices.getAcccountDetails(accountNo)==null) throw new AccountNotFoundException("Account Not Found");
		return daoServices.balanceEnquiry(accountNo);
	}

	@Override
	public float deposit(int accountNo, float amount) throws AccountNotFoundException, InvalidAmountException {
		if(amount<0) throw new InvalidAmountException("Please Enter Valid Amount");
		if(daoServices.getAcccountDetails(accountNo)==null) throw new AccountNotFoundException("Account Not Found");
		BankUtility.getAccountList().get(accountNo).setBalance(BankUtility.getAccountList().get(accountNo).getBalance()+amount);
		return daoServices.balanceEnquiry(accountNo);
	}

	@Override
	public float withdrawl(int accountNo, float amount)
			throws AccountNotFoundException, InvalidAmountException, InsufficientAmountException {
		if(daoServices.getAcccountDetails(accountNo)==null) throw new AccountNotFoundException("Account Not Found");
		if(amount<0) throw new InvalidAmountException("Please Enter Valid Amount");
		if(amount>BankUtility.getAccountList().get(accountNo).getBalance()) throw new InsufficientAmountException("No Suffcient Balance");
		if(amount<BankUtility.getAccountList().get(accountNo).getBalance())
			BankUtility.getAccountList().get(accountNo).setBalance(BankUtility.getAccountList().get(accountNo).getBalance()-amount);
		return daoServices.balanceEnquiry(accountNo);
	}

	@Override
	public float fundTransfer(int accountNoFrom, int accountNoTo, float amount)
			throws AccountNotFoundException, InvalidAmountException, InsufficientAmountException {
		withdrawl(accountNoFrom, amount);
		deposit(accountNoTo, amount);
		return daoServices.balanceEnquiry(accountNoFrom);
	}

}
