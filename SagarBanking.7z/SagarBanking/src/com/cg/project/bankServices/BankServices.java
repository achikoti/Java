package com.cg.project.bankServices;

import com.cg.project.exception.AccountNotFoundException;

import com.cg.project.beans.Account;
import com.cg.project.exception.InsufficientAmountException;
import com.cg.project.exception.InvalidAmountException;

public interface BankServices {
	public int createAccount(Account account) ;
	public float showBalance(int accountNo) throws AccountNotFoundException ;
	public float deposit(int accountNo,float amount) throws AccountNotFoundException,InvalidAmountException;
	public float withdrawl(int accountNo,float amount) throws AccountNotFoundException,InvalidAmountException,InsufficientAmountException;
	public float fundTransfer(int accountNoFrom,int accountNoTo,float amount)throws AccountNotFoundException,InvalidAmountException,InsufficientAmountException;
}
