package com.cg.project.main;

import java.util.Scanner;

import com.cg.project.exception.AccountNotFoundException;

import com.cg.project.bankServices.BankServices;
import com.cg.project.bankServices.BankServicesImpl;
import com.cg.project.beans.Account;
import com.cg.project.beans.Address;
import com.cg.project.beans.Customer;
import com.cg.project.exception.InsufficientAmountException;
import com.cg.project.exception.InvalidAmountException;

public class MainClass {

	public static void main(String[] args) throws AccountNotFoundException, InvalidAmountException, InsufficientAmountException {
		BankServices bankServices=new BankServicesImpl();
		int choice=0;
		
		do {
			System.out.println("\n 1. Create the Account");
			System.out.println("\n 2. Show Balance");
			System.out.println("\n 3. Deposit Amount");
			System.out.println("\n 4. Withdraw Amount");
			System.out.println("\n 5. Fund Transfer");
			System.out.println("\n 6. Exit");
			Scanner scanner=new Scanner(System.in);
			System.out.print("\n Enter your Choice: ");
			choice=scanner.nextInt();
			switch(choice) {
			case 1:
				System.out.print("\n Enter the FirstName: ");
				String firstName=scanner.next();
				System.out.print("\n Enter the LastName: ");
				String lastName=scanner.next();
				System.out.print("\n Enter the EmailId: ");
				String emailId=scanner.next();
				System.out.print("\n Enter the AadharNo: ");
				String aadharNo=scanner.next();
				System.out.println("\n Enter Address");
				System.out.print("\n Enter the FlatNo:");
				String flatNo=scanner.next();
				System.out.print("\n Enter the Street:");
				String street=scanner.next();
				System.out.print("\t Enter  City : ");
				String  city = scanner.next().toUpperCase();
				System.out.print("\t Enter  State : ");
				String state = scanner.next().toUpperCase();
				System.out.print("\t Enter PINCODE: ");
				int pincode = scanner.nextInt();
				System.out.print("\n Enter the Balance: ");
				float balance=scanner.nextFloat();
				System.out.println("The Account No generated is: "+bankServices.createAccount(new Account(balance, new Customer(firstName, lastName, emailId, aadharNo, new Address(pincode, city, state, flatNo, street)))));
				break;
			case 2:
				System.out.print("\n Enter the Account No:");
				int accountNo=scanner.nextInt();
				System.out.println("\n The balance in the account is: "+bankServices.showBalance(accountNo));
				break;
			case 3:
				System.out.print("\n Enter the Account No:");
				int accountNoCase3=scanner.nextInt();
				System.out.print("\n Enter the Amount to be Deposited: ");
				float amountCase3=scanner.nextFloat();
				System.out.println("\n The balance in the account is: "+bankServices.deposit(accountNoCase3, amountCase3));
				break;
			case 4:
				System.out.print("\n Enter the Account No:");
				int accountNoCase4=scanner.nextInt();
				System.out.print("\n Enter the Amount to be Withdrawn: ");
				float amountCase4=scanner.nextFloat();
				System.out.println("\n The balance in the account is: "+bankServices.withdrawl(accountNoCase4, amountCase4));
				break;
			case 5:
				System.out.print("\n Enter the Giver Account No:");
				int accountNoFromCase5=scanner.nextInt();
				System.out.print("\n Enter the Receiver Account No:");
				int accountNoToCase5=scanner.nextInt();
				System.out.print("\n Enter the Amount to be Transferred: ");
				float amountCase5=scanner.nextFloat();
				System.out.println("\n The balance in the account is: "+bankServices.fundTransfer(accountNoFromCase5, accountNoToCase5, amountCase5));
				break;
			case 6:
				System.out.println("You are go to Exit,Thank You!!!");
				break;
			default:
				System.out.println("Please Enter Valid Option!!!");
				break;
			}
		}while(choice!=6);

	}

}
