package com.cg.project.utility;

import java.util.HashMap;
import java.util.Map;

import com.cg.project.beans.Account;

public class BankUtility {
	private static Map<Integer, Account> accountList=new HashMap<>();
	private static int account_Id_Counter=1;

	public static int getAccount_Id_Counter() {
		return account_Id_Counter;
	}

	public static void setAccount_Id_Counter(int account_Id_Counter) {
		BankUtility.account_Id_Counter = account_Id_Counter;
	}

	public static Map<Integer, Account> getAccountList() {
		return accountList;
	}

	public static void setAccountList(Map<Integer, Account> accountList) {
		BankUtility.accountList = accountList;
	}
	

}
