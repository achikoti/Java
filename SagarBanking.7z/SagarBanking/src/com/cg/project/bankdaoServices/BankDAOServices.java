package com.cg.project.bankdaoServices;

import java.util.List;

import com.cg.project.beans.Account;

public interface BankDAOServices {
	public int insertAccount(Account account);
	public float balanceEnquiry(int accountNo);
	public Account getAcccountDetails(int accountNo);
	public List<Account> getAllAccountDetails();
}
