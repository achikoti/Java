package com.cg.project.bankdaoServices;

import java.util.ArrayList;
import java.util.List;

import com.cg.project.beans.Account;
import com.cg.project.utility.BankUtility;

public class BankDAOServicesImpl implements BankDAOServices{

	@Override
	public int insertAccount(Account account) {
		account.setId(BankUtility.getAccount_Id_Counter());
		BankUtility.getAccountList().put(BankUtility.getAccount_Id_Counter(),account);
		BankUtility.setAccount_Id_Counter(BankUtility.getAccount_Id_Counter()+1);
		return account.getId();
	}

	@Override
	public float balanceEnquiry(int accountNo) {
		return BankUtility.getAccountList().get(accountNo).getBalance();
	}

	@Override
	public Account getAcccountDetails(int accountNo) {
		return BankUtility.getAccountList().get(accountNo);
	}

	@Override
	public List<Account> getAllAccountDetails() {
		return new ArrayList<>(BankUtility.getAccountList().values());
	}
}
