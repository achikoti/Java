package com.cg.payroll.daoservices;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import com.cg.payroll.beans.Associate;
public class PayrollDAOServicesImpl implements PayrollDAOServices{
	private static HashMap<Integer, Associate> associates=new HashMap<>();
	private static int ASSOCIATE_ID_COUNTER=111;
	private static int ASSOCIATE_IDX_COUNTER=0;
	@Override
	public int insertAssociate(Associate associate) {
		associates.put(ASSOCIATE_ID_COUNTER++, associate);
		return associate.getAssociateID();
	}
	@Override
	public boolean updateAssociate(Associate associate) {
		associates.put(associate.getAssociateID(), associate);
		return true;
	}
	@Override
	public boolean deleteAssociate(int associateID) {
		associates.remove(associateID);
		return false;
	}
	@Override
	public Associate getAssociate(int associateID) {
		associates.get(associateID);
		return null;
	}
	@Override
	public List<Associate> getAssociates() {
		List<Associate> associateList = new ArrayList<Associate>(associates.values());
		return associateList;
	}
	
}
