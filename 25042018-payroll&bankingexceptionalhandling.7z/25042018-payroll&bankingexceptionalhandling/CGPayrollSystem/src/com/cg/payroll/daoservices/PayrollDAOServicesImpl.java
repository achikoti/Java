package com.cg.payroll.daoservices;
import java.util.Arrays;
import com.cg.payroll.beans.Associate;
public class PayrollDAOServicesImpl implements PayrollDAOServices{
	private static Associate[] associateList=new Associate[10];
	private static int ASSOCIATE_ID_COUNTER=111;
	private static int ASSOCIATE_IDX_COUNTER=0;
	@Override
	public int insertAssociate(Associate associate) {			
		if( ASSOCIATE_IDX_COUNTER >70*associateList.length/100) {
			Associate[] tempList;
			tempList=Arrays.copyOf(associateList, 10+(ASSOCIATE_IDX_COUNTER-1) );
			associateList=tempList;
		}
		associate.setAssociateID(ASSOCIATE_ID_COUNTER++);
		associateList[ASSOCIATE_IDX_COUNTER++]=associate;
		return associate.getAssociateID();
	}
	@Override
	public boolean updateAssociate(Associate associate) {
		for(int i=0;i<associateList.length;i++) {
			if(associateList[i]!=null&&associate.getAssociateID()==associateList[i].getAssociateID()) {
				associateList[i]=associate;
				/*associateList[i].setFirstName(associate.getFirstName());
				associateList[i].setLastName(associate.getLastName());*/
				return true;
			}
		}
		return false;
	}
	@Override
	public boolean deleteAssociate(int associateID) {
		int i;
		for(i=0;i<associateList.length;i++) 
			if(associateList[i]!=null&&associateID==associateList[i].getAssociateID()) {
				associateList[i]=null;
				associateList[i]=associateList[i+1];
				associateList[i+1]=null;
				return true;
			}
		int j;
		for(j=i+1;j<ASSOCIATE_IDX_COUNTER-1;j++) {
			if(associateList[j]==null) {
				associateList[j]=associateList[j+1];
			}
		}
		int k=ASSOCIATE_IDX_COUNTER-1;
		k=j+1;
		return false;
	}
	@Override
	public Associate getAssociate(int associateID) {
		for(int i=0;i<associateList.length;i++) 
			if(associateList[i]!=null&&associateID==associateList[i].getAssociateID())
				return associateList[i];
		return null;
	}
	@Override
	public Associate[] getAssociates() {
		return associateList;
	}
}
