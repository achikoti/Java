package com.cg.banking.daoservices;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.CustomerNotFoundException;
public interface BankingDAOServices {
	int insertCustomer(Customer customer);
	long insertAccount(int customerId,Account account);
	boolean updateAccount(int customerId,Account account)throws AccountBlockedException,CustomerNotFoundException;
	int generatePin(int customerId,Account account);
	boolean insertTransaction(int customerId,long accountNo,Transaction transaction)throws AccountBlockedException,CustomerNotFoundException;
	boolean deleteCustomer(int customerId)throws CustomerNotFoundException ;
	boolean deleteAccount(int customerId,long accountNo)throws CustomerNotFoundException,AccountNotFoundException;
	Customer getCustomer(int customerId)throws CustomerNotFoundException;
	Account getAccount(int customerId,long accountNo);
	Customer[] getCustomers();
	Account[] getAccounts(int customerId);
	Transaction[] getTransactions(int customerId,long accountNo);
}