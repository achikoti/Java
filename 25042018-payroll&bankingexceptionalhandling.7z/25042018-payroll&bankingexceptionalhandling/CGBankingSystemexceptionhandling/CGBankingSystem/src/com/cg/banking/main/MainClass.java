package com.cg.banking.main;

import com.cg.banking.beans.*;
import com.cg.banking.services.*;
import com.cg.banking.daoservices.*;

public class MainClass {
	public static void main(String[] args) {
		try {
			BankingServices bankingServies = new BankingServicesImpl();
			BankingDAOServices bankingdaoservices=new BankingDAOServicesImpl();
			
			int customer1 = bankingServies.acceptCustomerDetails("satish", "mahajan", "satish@abcd.com", "s1", "pune", "maharastra", 411062, "mumbai", "maharastra", 411052);
			//System.out.println(customer1);
			
			long account11=bankingServies.openAccount(customer1, "Savings", 20000);
			//System.out.println(account11);
			
			long account12=bankingServies.openAccount(customer1, "Salary", 30000);
			//System.out.println(account12);
			
			long account13=bankingServies.openAccount(customer1, "Current", 50000);
			System.out.println(account13);
			
			long account14=bankingServies.openAccount(customer1, "Transaction", 50000);
			System.out.println(account14);
			
			long account15=bankingServies.openAccount(customer1, "Child", 50000);
			System.out.println(account15);
			
			Account[] account=bankingdaoservices.getAccounts(customer1);
			System.out.println(account.length);
			
			float totalBalancead1=bankingServies.depositAmount(customer1, account11, 10000);
			System.out.println(totalBalancead1);
			
			float totalBalancead2=bankingServies.depositAmount(customer1, account12, 10000);
			System.out.println(totalBalancead2);
			
			int pin1=bankingServies.generateNewPin(customer1, account11);
			System.out.println(pin1);
			
			int pin2=bankingServies.generateNewPin(customer1, account12);
			System.out.println(pin2);
			
			int pin3=bankingServies.generateNewPin(customer1, account13);
			System.out.println(pin3);
			
			
			float totalBalanceaw1=bankingServies.withdrawAmount(customer1, account11, 100, pin1);
			System.out.println(totalBalanceaw1);
			float totalBalanceaw2=bankingServies.withdrawAmount(customer1, account12, 100, pin2);
			System.out.println(totalBalanceaw2);
			float totalBalanceaw3=bankingServies.withdrawAmount(customer1, account13, 100, pin3);
			System.out.println(totalBalanceaw3);
			boolean a=bankingServies.fundTransfer(customer1, account12, customer1, account11, 500000, pin1);
			System.out.println(a);
			System.out.println(bankingServies.getAccountDetails(customer1, account11).getAccountBalance());
			boolean b=bankingServies.fundTransfer(customer1, account13, customer1, account12, 5000, pin2);
			System.out.println(b);
			System.out.println(bankingServies.getAccountDetails(customer1, account12).getAccountBalance());
			
			int newpin1=bankingServies.generateNewPin(customer1, account11);
			System.out.println(newpin1);
			
			Transaction[] transaction=bankingServies.getAccountAllTransaction(customer1, account11);
			for(int i=0;i<transaction.length;i++) {
				System.out.println(transaction[i]);
			}
			
			Customer[] customer=bankingServies.getAllCustomerDetails();
			for(int i=0;i<customer.length;i++) {
				System.out.println(customer[i]);
			}
			
		} catch (Exception e) {
		e.printStackTrace();
		}
		
		
	}
}
