package com.cg.banking.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;



public class MainClass {

	public static void main(String[] args) throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
		BankingServices bankingServices=(BankingServices)applicationContext.getBean("bankingServices");
		try {
			int customerId=bankingServices.acceptCustomerDetails("abhinav", "chikoti", "abc@gmail.com", "a111", "medak", "tel", 502110, "hyd", "tel", 500006);
			System.out.println(customerId);
			bankingServices.openAccount(customerId, "savings",100000);
			bankingServices.openAccount(customerId, "savings",100000);
			int pinNumber =bankingServices.generateNewPin(customerId, 2);
			bankingServices.depositAmount(customerId, 1, 10000);
			bankingServices.withdrawAmount(customerId, 2, 1000, pinNumber);
			//bankingServices.deleteAccount(1, 2);
			System.out.println(bankingServices.getAccountDetails(1, 1));
			System.out.println(bankingServices.getAllCustomerDetails());
			int customerId2=bankingServices.acceptCustomerDetails("aishu", "patil", "abc@gmail.com", "a111", "medak", "tel", 502110, "hyd", "tel", 500006);
			bankingServices.openAccount(customerId2, "savings",100000);
			bankingServices.openAccount(customerId2, "savings",100000);
		//	bankingServices.fundTransfer(customerId2, 3, customerId, 2, 1000, pinNumber);
			System.out.println(bankingServices.getAccountDetails(1, 4));
			//bankingServices.deleteAccount(2, 2);
		} catch (BankingServicesDownException e) {
			e.printStackTrace();
		}
	}

}
