package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;

public interface PayrollServices {

	int acceptAssociateDetails(String firstName, String lastName, String emailId, String department, String designation,
			String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf, int accountNumber,
			String bankName, String ifscCode);

	int calculateNetSalary(int associateID);

	Associate getAssociateDetails(int associateID);

	Associate[] getAllAssociatesDetails();

}