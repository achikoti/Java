package com.cg.payroll.daoservices;

import com.cg.payroll.beans.Associate;

public class PayrollDAOServicesImpl implements PayrollDAoServices{

	private static Associate[] associateList=new Associate[10];
	private static int ASSOCIATE_ID_COUNTER=111;
	private static int ASSOCIATE_IDX_COUNTER=0;

		/* (non-Javadoc)
		 * @see com.cg.payroll.daoservices.PayrollDAoServices#insertAssociate(com.cg.payroll.beans.Associate)
		 */
		@Override
		public int insertAssociate(Associate associate) {
		associate.setAssociateID(ASSOCIATE_ID_COUNTER++);
		associateList[ASSOCIATE_IDX_COUNTER++]=associate;
		return associate.getAssociateID();
	}
	
	/* (non-Javadoc)
	 * @see com.cg.payroll.daoservices.PayrollDAoServices#updateAssociate(com.cg.payroll.beans.Associate)
	 */
	@Override
	public boolean updateAssociate(Associate associate) {
		for(int i=0;i<associateList.length;i++) 
			if(associateList[i]!=null&&associate.getAssociateID()==associateList[i].getAssociateID()) {
				associateList[i]=associate;
			/*associateList[i].setFirstName(associate.getFirstName());
				associateList[i].setLastName(associate.getLastName());*/
			return true;
			}
		return false;
}
	
	/* (non-Javadoc)
	 * @see com.cg.payroll.daoservices.PayrollDAoServices#deleteAssociate(int)
	 */
	@Override
	public boolean deleteAssociate(int associateID) {
		for(int i=0;i<associateList.length;i++) 
			if(associateList[i]!=null&&associateID==associateList[i].getAssociateID()) {
				associateList[i]=null;
				return true;
			}
		return false;
	}
	
	/* (non-Javadoc)
	 * @see com.cg.payroll.daoservices.PayrollDAoServices#getAssociate(int)
	 */
	@Override
	public Associate getAssociate(int associateID) {
		for(int i=0;i<associateList.length;i++) 
			if(associateList[i]!=null&&associateID==associateList[i].getAssociateID()) {
				return associateList[i];
			}
		return null;
	}
	
	/* (non-Javadoc)
	 * @see com.cg.payroll.daoservices.PayrollDAoServices#getAssociates()
	 */
	@Override
	public Associate[] getAssociates() {
		return associateList;
	}
}
