package com.cg.project.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FourZeroOneServlet
 */
@WebServlet("/FourZeroOneServlet")
public class FourZeroOneServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FourZeroOneServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//401-Error
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		PrintWriter writer=response.getWriter();
				if(!userName.equals(password)) {
					response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "UnAuthorized Login,Please Try Again!!!");
					writer.println("<font color='red' size='2'>Username And Password doesnot match</font>");
					writer.println("<br />");
					writer.println("<font color='red' size='2'>Access Denied </font>");
					writer.println("<br />");
					writer.println("<font color='red' size='2'>UserName:</font>"+userName+"<font color='red' size='2'>,with your Password: </font>"+password);
				}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
