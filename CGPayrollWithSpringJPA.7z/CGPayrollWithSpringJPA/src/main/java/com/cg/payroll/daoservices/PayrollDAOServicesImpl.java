package com.cg.payroll.daoservices;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
@Component("payrollDAOServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices{


	@Autowired(required=true)
	private EntityManagerFactory entityManagerFactory;
	@Override
	public int insertAssociate(Associate associate) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return associate.getAssociateID();
	}

	@Override
	public boolean updateAssociate(Associate associate) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	@Override
	public boolean deleteAssociate(int associateID) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Associate associate=entityManager.find(Associate.class,associateID);
		if(associate!=null) {
			entityManager.remove(associate);
			entityManager.flush();
			entityManager.getTransaction().commit();
		}
		entityManager.close();
		return true;
	}

	@Override
	public Associate getAssociate(int associateID) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		return entityManager.find(Associate.class,associateID);
	}

	@Override
	public List<Associate> getAssociates() {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		TypedQuery<Associate> query = entityManager.createQuery("Select a from Associate a",Associate.class);
		return query.getResultList();
	}


}
