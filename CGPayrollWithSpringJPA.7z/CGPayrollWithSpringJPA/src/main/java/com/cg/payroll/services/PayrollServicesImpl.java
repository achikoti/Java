package com.cg.payroll.services;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.utility.PayrollUtility;
import com.cg.payroll.daoservices.PayrollDAOServices;
@Component("payrollServices")
public class PayrollServicesImpl implements PayrollServices {
	@Autowired
	private PayrollDAOServices daoServices;

	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode) throws PayrollServicesDownException {
		
		
			return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
		
	}

	public int calculateNetSalary(int associateID)
			throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		Associate associate=daoServices.getAssociate(associateID);
		System.out.println("in calc"+associate);
		int taxAmount=0;
		if(associate!=null){
			associate.getSalary().setPersonalAllowance((int)30*associate.getSalary().getBasicSalary()/100);
			associate.getSalary().setConveyenceAllowance((int)20*associate.getSalary().getBasicSalary()/100);
			associate.getSalary().setOtherAllowance((int)10*associate.getSalary().getBasicSalary()/100);
			associate.getSalary().setHra((int)(25/10)*associate.getSalary().getBasicSalary()/100);
			associate.getSalary().setGratuity((int)50*associate.getSalary().getBasicSalary()/100);
			associate.getSalary().setGrossSalary(associate.getSalary().getPersonalAllowance()+associate.getSalary().getBasicSalary()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getHra()+associate.getSalary().getCompanyPf());
			int annualSalary=associate.getSalary().getGrossSalary()*12;
			int taxableSalary=annualSalary;
			int nonTaxableSalary=associate.getYearlyInvestmentUnder80C()+(associate.getSalary().getEpf()*12)+(associate.getSalary().getCompanyPf()*12);
			if(nonTaxableSalary>150000)
				nonTaxableSalary=150000;
			if(taxableSalary<=250000){
				taxAmount=0;
			}	
			else if(taxableSalary>250000 && taxableSalary<=500000){
				taxableSalary=taxableSalary-250000-nonTaxableSalary;
				if(taxableSalary<0)
					taxAmount=0;
				else
					taxAmount=taxableSalary*10/100;	
			}
			else if (taxableSalary>500000 && taxableSalary<=1000000){
				int taxSlab2=(500000-250000-nonTaxableSalary)*10/100;
				taxAmount=((taxableSalary-500000)*20/100)+taxSlab2;	
			}
			else if (taxableSalary>1000000){
				int taxSlab2=(500000-250000-nonTaxableSalary)*10/100;
				int taxSlab3=(500000)*20/100;
				taxAmount=((taxableSalary-1000000)*30/100)+taxSlab3+taxSlab2;	
			}
			associate.getSalary().setMonthlyTax((int)taxAmount/12);
			associate.getSalary().setNetSalary((int)(((annualSalary-taxAmount)/12)-associate.getSalary().getCompanyPf()-associate.getSalary().getEpf()));
			daoServices.updateAssociate(associate);
			return associate.getSalary().getNetSalary() ;
		}
		return 0;
	}



	public List<Associate> getAllAssociatesDetails() throws PayrollServicesDownException {
		
		return daoServices.getAssociates();
	}

	public boolean updateAssociateDetails(Associate associate)
			throws AssociateDetailsNotFoundException, PayrollServicesDownException, SQLException {
		
		return daoServices.updateAssociate(associate);
	}

	public boolean deleteAssociate(int associateID) throws SQLException {
		return daoServices.deleteAssociate(associateID);
	}

	@Override
	public Associate getAssociateDetails(int associateID)
			throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		
		return daoServices.getAssociate(associateID);
	}
	
	
}
