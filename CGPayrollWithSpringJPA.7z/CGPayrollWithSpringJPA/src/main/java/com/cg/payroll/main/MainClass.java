package com.cg.payroll.main;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.beans.Associate;

import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;
import com.cg.payroll.daoservices.*;
import com.cg.payroll.exceptions.*;

public class MainClass {

	public static void main(String[] args) throws PayrollServicesDownException, IOException, AssociateDetailsNotFoundException, SQLException {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
		PayrollServices payrollServices=(PayrollServices)applicationContext.getBean("payrollServices");
		payrollServices.acceptAssociateDetails("abhinav", "chikoti", "abc@gmail.com", "java", "analyst", "abcd1234", 12000, 15000, 1200, 1200, 11112222, "CITI", "citi005");
		//payrollServices.deleteAssociate(1);
		
		payrollServices.calculateNetSalary(1);
		//payrollServices.deleteAssociate(1);
		//System.out.println(payrollServices.getAssociateDetails(1));
		//System.out.println(payrollServices.getAllAssociatesDetails());
	}

}


