package com.cg.payroll.services;
import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.daoservices.PayrollDAOServices;
public class PayrollServicesImpl implements PayrollServices{

	PayrollDAOServices daoServices = new PayrollDAOServicesImpl();
	public PayrollServicesImpl() {

	}

	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#acceptAssociateDetails(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, int, int, int, int, int, java.lang.String, java.lang.String)
	 */
	@Override
	public int acceptAssociateDetails(String firstName, String lastName,
			String emailId,String department, String designation, String pancard,
			int yearlyInvestmentUnder80C,int basicSalary,int epf,int companyPf,int accountNumber
			,String bankName, String ifscCode) {
		/*Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode));
			daoServices.insertAssociate(associate);
				return associate.getAssociateID();*/
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
	}
	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#calculateNetSalary(int)
	 */
	@Override
	public int calculateNetSalary(int associateID) throws AssociateDetailsNotFoundException {
		Associate associate=this.getAssociateDetails(associateID);
		if(associate!=null) {
			associate.getSalary().setPersonalAllowance((int)((0.3)*(associate.getSalary().getBasicSalary())));
			associate.getSalary().setConveyenceAllowance((int)(0.2*(associate.getSalary().getBasicSalary())));
			associate.getSalary().setOtherAllowance((int)(0.1*(associate.getSalary().getBasicSalary())));
			associate.getSalary().setHra((int)(0.25*(associate.getSalary().getBasicSalary())));
			associate.getSalary().setGratuity((int)(0.05*(associate.getSalary().getBasicSalary())));
			int totalAllowances = associate.getSalary().getPersonalAllowance()
					+associate.getSalary().getConveyenceAllowance()
					+associate.getSalary().getHra()
					+associate.getSalary().getOtherAllowance();
			int monthlyGrossSalary = associate.getSalary().getBasicSalary()
					+totalAllowances
					+associate.getSalary().getCompanyPf();
			associate.getSalary().setGrossSalary(monthlyGrossSalary);
			int annualGrossSalary = monthlyGrossSalary*12;

			int annualEpf = associate.getSalary().getEpf()*12;

			int annualCompanypf = associate.getSalary().getCompanyPf()*12;
			/*int i,j,tax;
			if((associate.getYearlyInvestmentUnder80C()+associate.getSalary().getCompanyPf())>=150000) {
				j=1500000;
			}
			else
				j=associate.getYearlyInvestmentUnder80C()+associate.getSalary().getCompanyPf();
		   if(annualGrossSalary<250000) {
			   associate.getSalary().setNetSalary(monthlyGrossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
			   return (monthlyGrossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
		   }
		   else if(annualGrossSalary>=250000&&annualGrossSalary<500000) {
			   i=(annualGrossSalary-250000-j);
			   if(i<0)
				   tax=0;
			   tax=(int)(0.1*i)/12;
			   associate.getSalary().setMonthlyTax((int)(tax=(int)(0.1*i)/12));
			   associate.getSalary().setNetSalary(monthlyGrossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
			   return (monthlyGrossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
		   }
		   else if(annualGrossSalary>=500000&&annualGrossSalary<100000) {
			   i=(int)((250000-j)*0.1);
			   tax=(int)(((annualGrossSalary-500000)*0.2)+i)/12;
			   associate.getSalary().setMonthlyTax((int)(((annualGrossSalary-500000)*0.2)+i)/12);
			   associate.getSalary().setNetSalary(monthlyGrossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-tax);
			   return (monthlyGrossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-tax); 
		   }
		   else if(annualGrossSalary>100000) {
			   i=(int)((2500000-j)*0.1);
			   tax=(int)((i+100000+((annualGrossSalary-1000000)*0.3))/12);
			   associate.getSalary().setMonthlyTax((int)((i+100000+((annualGrossSalary-1000000)*0.3))/12));
			   associate.getSalary().setNetSalary(monthlyGrossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-tax);
			   return (monthlyGrossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-tax); 

		   }*/



			int yearly80C= associate.getYearlyInvestmentUnder80C()-annualEpf-annualCompanypf;

			int taxableAmount = annualGrossSalary-yearly80C;

			int annualTax=0;

			if(taxableAmount>0) {
				if(taxableAmount<250000)
					annualTax=(int)(0.1*taxableAmount);
				if((taxableAmount>=250000)&&(taxableAmount>500000))
					annualTax=25000+(int)(0.2*(taxableAmount-250000));
				if(taxableAmount>=500000)
					annualTax=25000+100000+(int)(0.3*(taxableAmount-750000));	
			}
			//int monthlyTax=annualTax/12;
			associate.getSalary().setMonthlyTax(annualTax/12);
			/*int monthlyNetSalary= monthlyGrossSalary-associate.getSalary().getMonthlyTax()
							-associate.getSalary().getEpf()
							-associate.getSalary().getCompanyPf();*/

			associate.getSalary().setNetSalary( monthlyGrossSalary-associate.getSalary().getMonthlyTax()
					-associate.getSalary().getEpf()
					-associate.getSalary().getCompanyPf());






		}		

		return 0;
	}
	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#getAssociateDetails(int)
	 */
	@Override
	public Associate getAssociateDetails(int associateID)  throws AssociateDetailsNotFoundException{
		Associate associate =daoServices.getAssociate(associateID);
		if(associate==null)
			throw new AssociateDetailsNotFoundException("Associate details of  "+associateID+" not found");
		return associate;
	}
	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#getAllAssociatesDetails()
	 */
	@Override
	public Associate[] getAllAssociatesDetails() {
		return daoServices.getAssociates();
	}

}
