public class MainClass{
	public static void main(String[] str){
										//   aID, yIU,  fn     ,  ln  , dept   ,  desg     ,   pcn    ,    eid
		Associate associate1 = new Associate( 1,  100, "abhi"  , "ch" , "hr"   , "manager" , "abhi1"  , "abhi@abcd.com"  );
		Associate associate2 = new Associate( 2,  200, "sindhu", "p"  , "tech" , "dev"     , "sindhu2", "sindhu@abcd.com");
		Associate associate3 = new Associate( 3,  300, "dipu"  , "s"  , "train", "sr con"  , "dipu3"  , "dipu@abcd.com"  );
		Associate associate4 = new Associate( 4,  400, "sun"   , "d"  , "maint", "chief"   , "sun4"   , "sun@abcd.com"   );
		Associate associate5 = new Associate( 5,  500, "moon"  , "g"  , "hr"   , "ceo"     , "moon1"  , "moon@abcd.com"  );
												// bano, bn,ifcode
		BankDetails bankdetails1 = new BankDetails(123 ,"z", "z1" );
		BankDetails bankdetails2 = new BankDetails(345 ,"y", "y1" );
		BankDetails bankdetails3 = new BankDetails(456 ,"x", "x1" );
		BankDetails bankdetails4 = new BankDetails(789 ,"w", "w1" );
		BankDetails bankdetails5 = new BankDetails(012 ,"v", "v1" );
									//bs,  hra,ca, oa, pa, tax , epf, cpf , gty , gs  , ns   
		Salary salary1 = new Salary(1000 , 10, 11, 12, 13,  14 , 15 , 16  , 17  , 1014, 920);
		Salary salary2 = new Salary(2000 , 10, 11, 12, 13,  14 , 15 , 16  , 17  , 2014, 1920);
		Salary salary3 = new Salary(3000 , 10, 11, 12, 13,  14 , 15 , 16  , 17  , 3014, 2920);
		Salary salary4 = new Salary(4000 , 10, 11, 12, 13,  14 , 15 , 16  , 17  , 4014, 3920);
		Salary salary5 = new Salary(5000 , 10, 11, 12, 13,  14 , 15 , 16  , 17  , 5014, 4920);
		
		//associate.setAssociateID(2351);
		//associate.getYearlyInvestmentUnder80C();
		System.out.print(" AssociateID: "+associate5.getAssociateID()
							+"\n YearlyInvestmentUnder80C: "+associate5.getYearlyInvestmentUnder80C()
							+"\n FirstName: "+associate5.getFirstName()
							+"\n LastName: "+associate5.getLastName()
							+"\n Department: "+associate5.getDepartment()
							+"\n Designation: "+associate5.getDesignation()
							+"\n PanCard No: "+associate5.getPancard()+"\n EmailId: "+associate5.getEmailid());
		System.out.print("\n Bank Account No: "+bankdetails5.getAccountNumber()
							+"\n BankName: "+bankdetails5.getBankName()
							+"\n IFSC CODE: "+bankdetails5.getIfscCode());
		System.out.print("\n Basic Salary: "+salary5.getBasicSalary()
							+"\n hra:" +salary5.getHra()
							+"\n ConveyenceAllowance: "+salary5.getConveyenceAllowance()
							+"\n OtherAllowances: "+salary5.getOtherAllowance()
							+"\n Personal Allowance: "+salary5.getPersonalAllowance()
							+"\n Monthly Tax: " +salary5.getMonthlyTax()
							+"\n EPF: "+salary5.getEpf()
							+"\n CompanyPf: "+salary5.getCompanyPf()
							+"\n Gratuity: "+salary5.getGratuity()
							+"\n GrossSalary: "+salary5.getGrossSalary()
							+"\n NetSalary: "+salary5.getNetSalary());
	}
}