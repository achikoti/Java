package com.cg.banking.daoservices;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.utility.BankingUtility;

public class BankingDAOServicesImpl implements BankingDAOServices {
	//private static Customer[] customerList = new Customer[10];
	public static HashMap<Integer,Customer> customers= new HashMap<>();
	
	//private static int CUSTOMER_IDX_COUNTER=0;
	private  Random random=new Random();
	@Override
	public int insertCustomer(Customer customer) {

		customers.put(BankingUtility.CUSTOMER_ID_COUNTER,customer);
		customer.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER++);
		/*if( CUSTOMER_IDX_COUNTER >70*customerList.length/100) {
			Customer[] tempList;
			tempList=Arrays.copyOf(customerList, 10+customerList.length );
			customerList=tempList;
		}
		customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		customerList[CUSTOMER_IDX_COUNTER++]=customer;*/
		return customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		account.setStatus("Active");
		customers.get(customerId).getAccounts().put(BankingUtility.ACCOUNT_ID_COUNTER, account);
		customers.get(customerId).getAccounts().get(BankingUtility.ACCOUNT_ID_COUNTER).setAccountNo(BankingUtility.ACCOUNT_ID_COUNTER++);
		/*for(int i=0;i<customerList.length;i++) 
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId) {
				if(customerList[i].getACCOUNT_IDX_COUNTER()>70*customerList[i].getAccounts().length/100) {
					Account[] tempList;
					tempList = Arrays.copyOf(customerList[i].getAccounts(), 10+customerList[i].getAccounts().length);
					customerList[i].setAccounts(tempList);
				}
				account.setAccountNo(ACCOUNT_ID_COUNTER++);
				customerList[i].getAccounts()[customerList[i].getACCOUNT_IDX_COUNTER()]=account;
				customerList[i].setACCOUNT_IDX_COUNTER(customerList[i].getACCOUNT_IDX_COUNTER()+1);
				return account.getAccountNo();
			}*/

		return account.getAccountNo();
	}
	@Override
	public boolean updateAccount(int customerId, Account account) {
		if(customers.containsKey(customerId)==true) {
			if(customers.get(customerId).getAccounts().containsKey(account.getAccountNo())==true) {
				customers.get(customerId).getAccounts().put(BankingUtility.ACCOUNT_ID_COUNTER, account);
				customers.get(customerId).getAccounts().get(account.getAccountNo()).setAccountNo(BankingUtility.ACCOUNT_ID_COUNTER++);
				return true;
			}
		}
		/*for(int i=0;i<customerList.length;i++) {
			for(int j=0;j<customerList[i].getAccounts().length;j++) {			
				if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId&&customerList[i].getAccounts()[j]!=null
						&&customerList[i].getAccounts()[j].getAccountNo()==account.getAccountNo() ) {
					customerList[i].getAccounts()[j]=account;
					return true;
				}
			}
		}*/
		return false;
	}

	@Override
	public float balanceEnquiry(int customerId,long accountNo,int pinNumber) {
		if(customers.get(customerId).getAccounts().get(accountNo).getPinNumber()==pinNumber) {
			return this.getAccount(customerId, accountNo).getAccountBalance();
		}
		/*for(int i=0;i<customerList.length;i++) {
			for(int j=0;j<customerList[i].getAccounts().length;j++) {
				if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId&&customerList[i].getAccounts()[j]!=null
						&&customerList[i].getAccounts()[j].getAccountNo()==accountNo
						&&this.getAccount(customerId, accountNo).getPinNumber()==pinNumber) {
					return this.getAccount(customerId, accountNo).getAccountBalance();
				}
			}
		}*/
		return 0;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		getCustomer(customerId).getAccounts().get(account.getAccountNo()).setPinNumber(random.nextInt(10000));
		return account.getPinNumber();
		/*for(int i=0;i<customerList.length;i++) {
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId) {
				for(int j=0;j<customerList[i].getAccounts().length;j++) {
					if(customerList[i].getAccounts()[j]!=null&&customerList[i].getAccounts()[j]==account&&customerList[i].getAccounts()[j].getPinNumber()==0) {
						customerList[i].getAccounts()[j].setPinNumber(random.nextInt(10000));
						return customerList[i].getAccounts()[j].getPinNumber();
					}
					if(customerList[i].getAccounts()[j]!=null&&customerList[i].getAccounts()[j]==account&&customerList[i].getAccounts()[j].getPinNumber()!=0) {
						System.out.println("PIN has already generated for this account");
						customerList[i].getAccounts()[j].setPinNumber(this.random.nextInt(10000));
						return customerList[i].getAccounts()[j].getPinNumber();
					}
				}
			}
		}*/
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		if(getAccount(customerId, accountNo)==null)
			return false;

		customers.get(customerId).getAccounts().get(accountNo).getTransactions().put(BankingUtility.TRANSACTION_ID_COUNTER,transaction);
		customers.get(customerId).getAccounts().get(accountNo).getTransactions().get(BankingUtility.TRANSACTION_ID_COUNTER).setTransactionId(BankingUtility.TRANSACTION_ID_COUNTER++);
		return true;
		/*for(int i=0;i<customerList.length;i++) 
		for(int j=0;j<customerList[i].getAccounts().length;j++) 
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId
					&&customerList[i].getAccounts()[j].getAccountNo()==accountNo) {*/

		/*if(customerList[i].getAccounts()[j].getTRANSACTION_IDX_COUNTER()>70*customerList[i].getAccounts()[j].getTransactions().length/100) {
					Transaction[] tempList;
					tempList=Arrays.copyOf(customerList[i].getAccounts()[j].getTransactions(), 10+customerList[i].getAccounts()[j].getTransactions().length);
					customerList[i].getAccounts()[j].setTransactions(tempList);
				}*/
		/*transaction.setTransactionId(getAccount(customerId, accountNo).getTRANSACTION_ID_COUNTER());
		getAccount(customerId, accountNo).setTRANSACTION_ID_COUNTER(getAccount(customerId, accountNo).getTRANSACTION_ID_COUNTER()+1);
		getAccount(customerId, accountNo).getTransactions()[getAccount(customerId, accountNo).getTRANSACTION_IDX_COUNTER()]=transaction;
		getAccount(customerId, accountNo).setTRANSACTION_IDX_COUNTER(getAccount(customerId, accountNo).getTRANSACTION_IDX_COUNTER()+1);
		 */

		//customerList[i].getAccounts()[j].getTransactions()[customerList[i].getAccounts()[j].getTRANSACTION_IDX_COUNTER()]=transaction;
		//customerList[i].getAccounts()[j].getTransactions()[customerList[i].getAccounts()[j].getTRANSACTION_IDX_COUNTER()].setTransactionId(customerList[i].getAccounts()[j].getTRANSACTION_ID_COUNTER());
		//int tidcounter=customerList[i].getAccounts()[j].getTRANSACTION_ID_COUNTER();
		//tidcounter++;
		//int tidxcounter=customerList[i].getAccounts()[j].getTRANSACTION_IDX_COUNTER();
		//tidxcounter++;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		customers.remove(customerId);
		return true;
		/*for(int i=0;i<customerList.length;i++) 
			if(customerList[i]!=null&&customerId==customerList[i].getCustomerId()) {
				customerList[i]=null;
				return true;	
			}
		return false;*/
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {

		customers.get(customerId).getAccounts().remove(accountNo);
		return true;
		/*for(int i=0;i<customerList.length;i++) {
			for(int j=0;j<customerList[i].getAccounts().length;j++) {
				if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId
						&&customerList[i].getAccounts()[j].getAccountNo()==accountNo) {
					customerList[i].getAccounts()[j]=null;
					return true;
				}
			}
		}
		return false;*/
	}

	@Override
	public Customer getCustomer(int customerId) {
		return customers.get(customerId);
		/*for(int i=0;i<customerList.length;i++) 
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId) 
				return customerList[i];
		return null;*/
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		Account a=customers.get(customerId).getAccounts().get(accountNo);
		if(a==null)
			return null;
		return a;
		/*for(int i=0;i<customerList.length;i++) 
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId) 
				for(int j=i;j<customerList[i].getAccounts().length;j++) 
					if(customerList[i].getAccounts()[j]!=null&&customerList[i].getAccounts()[j].getAccountNo()==accountNo) 
						return customerList[i].getAccounts()[j];
		return null;*/
	}

	@Override
	public List<Customer> getCustomers() {
		return new ArrayList<>(customers.values());
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		return new ArrayList<>(getCustomer(customerId).getAccounts().values());
		//return getCustomer(customerId).getAccounts();
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		return new ArrayList<>(getAccount(customerId, accountNo).getTransactions().values());
		//return getAccount(customerId, accountNo).getTransactions();
	}
}
