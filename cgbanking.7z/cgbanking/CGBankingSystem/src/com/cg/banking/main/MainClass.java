package com.cg.banking.main;
import com.cg.banking.beans.*;
public class MainClass {
	public static void main(String[] args) {
	
		
	}
}
