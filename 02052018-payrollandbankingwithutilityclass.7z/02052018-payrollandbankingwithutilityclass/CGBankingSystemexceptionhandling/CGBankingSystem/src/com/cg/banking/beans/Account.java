package com.cg.banking.beans;

import java.util.Arrays;
import java.util.HashMap;

public class Account {
	private int pinNumber,pinCounter=0;
	private String accountType,status;
	private float accountBalance;
	private long accountNo;	
	//private Transaction [] transactions=new Transaction[10];
	private HashMap<Integer, Transaction> transactions=new HashMap<>();
	private int TRANSACTION_ID_COUNTER=1;
	private int TRANSACTION_IDX_COUNTER=0;
	public Account() {}
	
	public Account(String accountType, float accountBalance) {
		super();
		this.accountType = accountType;
		this.accountBalance = accountBalance;
	}

	public Account(int pinNumber, int pinCounter, String accountType, String status, float accountBalance,
			long accountNo, HashMap<Integer, Transaction> transactions, int tRANSACTION_ID_COUNTER,
			int tRANSACTION_IDX_COUNTER) {
		super();
		this.pinNumber = pinNumber;
		this.pinCounter = pinCounter;
		this.accountType = accountType;
		this.status = status;
		this.accountBalance = accountBalance;
		this.accountNo = accountNo;
		this.transactions = transactions;
		TRANSACTION_ID_COUNTER = tRANSACTION_ID_COUNTER;
		TRANSACTION_IDX_COUNTER = tRANSACTION_IDX_COUNTER;
	}

	public int getPinNumber() {
		return pinNumber;
	}

	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}

	public int getPinCounter() {
		return pinCounter;
	}

	public void setPinCounter(int pinCounter) {
		this.pinCounter = pinCounter;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public float getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public HashMap<Integer, Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(HashMap<Integer, Transaction> transactions) {
		this.transactions = transactions;
	}

	public int getTRANSACTION_ID_COUNTER() {
		return TRANSACTION_ID_COUNTER;
	}

	public void setTRANSACTION_ID_COUNTER(int tRANSACTION_ID_COUNTER) {
		TRANSACTION_ID_COUNTER = tRANSACTION_ID_COUNTER;
	}

	public int getTRANSACTION_IDX_COUNTER() {
		return TRANSACTION_IDX_COUNTER;
	}

	public void setTRANSACTION_IDX_COUNTER(int tRANSACTION_IDX_COUNTER) {
		TRANSACTION_IDX_COUNTER = tRANSACTION_IDX_COUNTER;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + TRANSACTION_IDX_COUNTER;
		result = prime * result + TRANSACTION_ID_COUNTER;
		result = prime * result + Float.floatToIntBits(accountBalance);
		result = prime * result + (int) (accountNo ^ (accountNo >>> 32));
		result = prime * result + ((accountType == null) ? 0 : accountType.hashCode());
		result = prime * result + pinCounter;
		result = prime * result + pinNumber;
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((transactions == null) ? 0 : transactions.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (TRANSACTION_IDX_COUNTER != other.TRANSACTION_IDX_COUNTER)
			return false;
		if (TRANSACTION_ID_COUNTER != other.TRANSACTION_ID_COUNTER)
			return false;
		if (Float.floatToIntBits(accountBalance) != Float.floatToIntBits(other.accountBalance))
			return false;
		if (accountNo != other.accountNo)
			return false;
		if (accountType == null) {
			if (other.accountType != null)
				return false;
		} else if (!accountType.equals(other.accountType))
			return false;
		if (pinCounter != other.pinCounter)
			return false;
		if (pinNumber != other.pinNumber)
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (transactions == null) {
			if (other.transactions != null)
				return false;
		} else if (!transactions.equals(other.transactions))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Account [pinNumber=" + pinNumber + ", pinCounter=" + pinCounter + ", accountType=" + accountType
				+ ", status=" + status + ", accountBalance=" + accountBalance + ", accountNo=" + accountNo
				+ ", transactions=" + transactions + ", TRANSACTION_ID_COUNTER=" + TRANSACTION_ID_COUNTER
				+ ", TRANSACTION_IDX_COUNTER=" + TRANSACTION_IDX_COUNTER + "]";
	}

	
	/*
	public Account(int pinNumber, int pinCounter, String accountType, String status, float accountBalance,
			long accountNo, Transaction[] transactions) {
		super();
		this.pinNumber = pinNumber;
		this.pinCounter = pinCounter;
		this.accountType = accountType;
		this.status = status;
		this.accountBalance = accountBalance;
		this.accountNo = accountNo;
		this.transactions = transactions;
	}
	public int getPinNumber() {
		return pinNumber;
	}
	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}
	public int getPinCounter() {
		return pinCounter;
	}
	public void setPinCounter(int pinCounter) {
		this.pinCounter = pinCounter;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public float getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public Transaction[] getTransactions() {
		return transactions;
	}
	public void setTransactions(Transaction[] transactions) {
		this.transactions = transactions;
	}
	public int getTRANSACTION_IDX_COUNTER() {
		return TRANSACTION_IDX_COUNTER;
	}
	public void setTRANSACTION_IDX_COUNTER(int tRANSACTION_IDX_COUNTER) {
		TRANSACTION_IDX_COUNTER = tRANSACTION_IDX_COUNTER;
	}
	public int getTRANSACTION_ID_COUNTER() {
		return TRANSACTION_ID_COUNTER;
	}
	public void setTRANSACTION_ID_COUNTER(int tRANSACTION_ID_COUNTER) {
		TRANSACTION_ID_COUNTER = tRANSACTION_ID_COUNTER;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + TRANSACTION_IDX_COUNTER;
		result = prime * result + TRANSACTION_ID_COUNTER;
		result = prime * result + Float.floatToIntBits(accountBalance);
		result = prime * result + (int) (accountNo ^ (accountNo >>> 32));
		result = prime * result + ((accountType == null) ? 0 : accountType.hashCode());
		result = prime * result + pinCounter;
		result = prime * result + pinNumber;
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + Arrays.hashCode(transactions);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (TRANSACTION_IDX_COUNTER != other.TRANSACTION_IDX_COUNTER)
			return false;
		if (TRANSACTION_ID_COUNTER != other.TRANSACTION_ID_COUNTER)
			return false;
		if (Float.floatToIntBits(accountBalance) != Float.floatToIntBits(other.accountBalance))
			return false;
		if (accountNo != other.accountNo)
			return false;
		if (accountType == null) {
			if (other.accountType != null)
				return false;
		} else if (!accountType.equals(other.accountType))
			return false;
		if (pinCounter != other.pinCounter)
			return false;
		if (pinNumber != other.pinNumber)
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (!Arrays.equals(transactions, other.transactions))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Account [pinNumber=" + pinNumber + ", pinCounter=" + pinCounter + ", accountType=" + accountType
				+ ", status=" + status + ", accountBalance=" + accountBalance + ", accountNo=" + accountNo
				+ ", transactions=" + Arrays.toString(transactions) + ", TRANSACTION_ID_COUNTER="
				+ TRANSACTION_ID_COUNTER + ", TRANSACTION_IDX_COUNTER=" + TRANSACTION_IDX_COUNTER + "]";
	}*/
	
}