package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/HelloServlet")
public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static int counter=0;
       
    
    	
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		doPost(request, response);
		
		PrintWriter writer=response.getWriter();
		counter++;
		
		if(counter<=3) {
			writer.println("<html>");
			writer.println("<head>");
			writer.println("<body>");
			writer.println("<div align='center'>");
			writer.println("<font color='olive' size='10'>Hello from HelloServlet()</font>");
			writer.println("</div>");
			writer.println("</body>");
			writer.println("</head>");
			writer.println("</html>");
		}
		else if(counter>3 && counter<=6) {
			writer.println("<html>");
			writer.println("<head>");
			writer.println("<body>");
			writer.println("<div align='center'>");
			writer.println("<font color='black' size='10'>Hello from HelloServlet()</font>");
			writer.println("</div>");
			writer.println("</body>");
			writer.println("</head>");
			writer.println("</html>");
		}
		else if(counter>6 && counter<=9) {
			writer.println("<html>");
			writer.println("<head>");
			writer.println("<body>");
			writer.println("<div align='center'>");
			writer.println("<font color='red' size='10'>Hello from HelloServlet()</font>");
			writer.println("</div>");
			writer.println("</body>");
			writer.println("</head>");
			writer.println("</html>");
		}
		if(counter>9) {
			counter=1;
			writer.println("<html>");
			writer.println("<head>");
			writer.println("<body>");
			writer.println("<div align='center'>");
			writer.println("<font color='olive' size='10'>Hello from HelloServlet()</font>");
			writer.println("</div>");
			writer.println("</body>");
			writer.println("</head>");
			writer.println("</html>");
		}
		
			
	}

	
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
//	}
//
//	/**
//	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
//	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
		response.getWriter().println("<html><body><p>Use "
				+ "GET instead!</p></body></html>");
		doGet(request, response);
	}

}
