package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.User;

/**
 * Servlet implementation class SignUpServlet
 */
@WebServlet("/SignUpServlet")
public class SignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String gender;

	/**
	 * @see HttpServlet#HttpServlet()
	 */


	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer=response.getWriter();
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		String emailId=request.getParameter("emailId");
		String mobileNo=request.getParameter("mobileNo");
		String getgender=request.getParameter("gender");
		if("male".equals(getgender)) {
			gender="male";
		}
		else if("female".equals(getgender)) {
			gender="female";
		}
		String[] communication=request.getParameterValues("communication");
		List list =  Arrays.asList(communication);
		 request.setAttribute("communication", list);
		String graduation=request.getParameter("graduation");
		
		

		writer.println("<html>");
		writer.println("<head>");
		writer.println("<body>");
		writer.println("<div align='center'>");
		if(userName.equals(password)) {
			writer.println("<font color='green' size='2'>Welcome </font>"+firstName);
			writer.println("<br />");
			writer.println("<font color='green' size='2'>UserName:</font>"+userName+"<font color='green' size='2'>,with your Password: </font>"+password);
		}
		else if(!userName.equals(password)) {
			writer.println("<font color='red' size='2'>Username And Password doesnot match</font>");
			writer.println("<br />");
			writer.println("<font color='red' size='2'>Welcome </font>"+firstName);
			writer.println("<br />");
			writer.println("<font color='red' size='2'>UserName:</font>"+userName+"<font color='red' size='2'>,with your Password: </font>"+password);
		}
		writer.println("</div>");
		writer.println("</body>");
		writer.println("</head>");
		writer.println("</html>");

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
