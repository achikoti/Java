package com.cg.banking.test;



import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.utility.BankingUtility;

public class BankingServicesTest {
	static BankingServices bankingServices;
	static BankingDAOServices bankingDAOServices;
	

	@BeforeClass
	public static void setUpTestEnv() {
		bankingServices=new BankingServicesImpl();
		bankingDAOServices=new BankingDAOServicesImpl();
	}
	
	@Before
	public void setUpMockData() {
		BankingUtility.CUSTOMER_ID_COUNTER=111;
		BankingUtility.ACCOUNT_ID_COUNTER=1;
		BankingUtility.TRANSACTION_ID_COUNTER=1;		
			
		BankingDAOServicesImpl.customers.put(BankingUtility.CUSTOMER_ID_COUNTER,new Customer("abhi", "ch", "abhi@abcd.com", "a1", new Address(123456, "hyd", "tel"), new Address(147852, "pune", "mhr")));
		BankingDAOServicesImpl.customers.get(BankingUtility.CUSTOMER_ID_COUNTER).getAccounts().put(BankingUtility.ACCOUNT_ID_COUNTER,new Account(1234, 0, "Savings", "Active", 10000,BankingUtility.ACCOUNT_ID_COUNTER));
		BankingDAOServicesImpl.customers.get(BankingUtility.CUSTOMER_ID_COUNTER++).getAccounts().get(BankingUtility.ACCOUNT_ID_COUNTER++).getTransactions().put(BankingUtility.TRANSACTION_ID_COUNTER++, new Transaction(BankingUtility.TRANSACTION_ID_COUNTER, 5000, "Deposit"));
		
		BankingDAOServicesImpl.customers.put(BankingUtility.CUSTOMER_ID_COUNTER,new Customer("abhi", "ch", "abhi@abcd.com", "a1", new Address(123456, "hyd", "tel"), new Address(147852, "pune", "mhr")));
		BankingDAOServicesImpl.customers.get(BankingUtility.CUSTOMER_ID_COUNTER).getAccounts().put(BankingUtility.ACCOUNT_ID_COUNTER,new Account(1234, 0, "Savings", "Active", 10000,BankingUtility.ACCOUNT_ID_COUNTER));
		BankingDAOServicesImpl.customers.get(BankingUtility.CUSTOMER_ID_COUNTER++).getAccounts().get(BankingUtility.ACCOUNT_ID_COUNTER++).getTransactions().put(BankingUtility.TRANSACTION_ID_COUNTER++, new Transaction(BankingUtility.TRANSACTION_ID_COUNTER, 5000, "Deposit"));
		
	}
	
	@Test
	public void testForValidCustomerID() throws BankingServicesDownException {
	assertEquals(112,bankingServices.acceptCustomerDetails("abhi", "ch", "abhi@abcd.com", "a1", "hyd", "tel",123456, "pune", "mhr",147852));
	}
	
	@Test
	public void testForInValidCustomerID() throws CustomerNotFoundException,BankingServicesDownException{
		assertNotEquals(114,bankingServices.acceptCustomerDetails("abhi", "ch", "abhi@abcd.com", "a1", "hyd", "tel",123456, "pune", "mhr",147852));
	}

	@Test
	public void testOpenAccountNoForValidCustomerID() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException {
		int customerId=bankingServices.acceptCustomerDetails("abhi", "ch", "abhi@abcd.com", "a1", "hyd", "tel",123456, "pune", "mhr",147852);
		assertEquals(2,bankingServices.openAccount(customerId,"Savings", 10000));
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testOpenAccountNoForInValidCustomerIDValidAccountNoValidAmount() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException {
		int customerId=bankingServices.acceptCustomerDetails("abhi", "ch", "abhi@abcd.com", "a1", "hyd", "tel",123456, "pune", "mhr",147852);
		assertEquals(2,bankingServices.openAccount(256,"Savings", 10000));
	}
	
	@Test(expected=InvalidAccountTypeException.class)
	public void testOpenAccountNoForValidCustomerIDInValidAccountNoValidAmount() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException {
		int customerId=bankingServices.acceptCustomerDetails("abhi", "ch", "abhi@abcd.com", "a1", "hyd", "tel",123456, "pune", "mhr",147852);
		assertEquals(2,bankingServices.openAccount(customerId,"Child", 10000));
	}
	
	@Test(expected=InvalidAmountException.class)
	public void testOnAccountNoForValidCustomerIDValidAccountNoInValidAmount() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException{
		int customerId=bankingServices.acceptCustomerDetails("abhi", "ch", "abhi@abcd.com", "a1", "hyd", "tel",123456, "pune", "mhr",147852);
		assertEquals(2,bankingServices.openAccount(customerId,"Savings", -250));
	}
	
	@Test
	public void testOnDepositAmountForValidCustomerIDValidAccountNoValidAmount() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException {
		assertEquals(15000, bankingServices.depositAmount(111, 1, 5000), 0);
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testOnDepositAmountForInValidCustomerIDValidAccountNoValidAmount() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException {
		bankingServices.depositAmount(100,1, 5000);
	}
	
	@Test(expected=AccountNotFoundException.class)
	public void testOnDepositAmountForValidCustomerIDInValidAccountNoValidAmount() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException {
		bankingServices.depositAmount(111,3, 5000);
	}
	
	@Test(expected=InvalidAmountException.class)
	public void testOnDepositAmountForValidCustomerIDValidAccountNoInValidAmount() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException {
		bankingServices.depositAmount(111,1, -250);
	}
	
	@Test(expected=AccountBlockedException.class)
	public void testOnDepositAmountForInVAccBlocked(){
		bankingServices.getAccountDetails(111,1).setStatus("Blocked");
		bankingServices.depositAmount(111,1,1000);
	}
	
	@Test
	public void testOnWithdrawAmountForValidCustomerIDValidAccountNoValidAmountValidPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException {
		assertEquals(9000, bankingServices.withdrawAmount(111,1,1000,1234), 0);
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testOnWithdrawAmountForInValidCustomerIDValidAccountNoValidAmountValidPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException {
		bankingServices.withdrawAmount(120,1,1000,1234);
	}
	
	@Test(expected=AccountNotFoundException.class)
	public void testOnWithdrawAmountForValidCustomerIDInValidAccountNoValidAmountValidPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException {
		bankingServices.withdrawAmount(111,-256,1000,1234);
	}
	
	@Test(expected=InvalidAmountException.class)
	public void testOnWithdrawAmountForValidCustomerIDValidAccountNoInValidAmountValidPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException {
		bankingServices.withdrawAmount(111,1,-1000,1234);
	}
	
	@Test(expected=InsufficientAmountException.class)
	public void testOnWithdrawAmountForValidCustomerIDValidAccountNoInSuffAmountValidPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException {
		bankingServices.withdrawAmount(111,1,20000,1234);
	}
	
	@Test(expected=InvalidPinNumberException.class)
	public void testOnWithdrawAmountForValidCustomerIDValidAccountNoValidAmountInValidPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException {
		bankingServices.withdrawAmount(111,1,1000,-100);
	}
	
	@Test(expected=AccountBlockedException.class)
	public void testOnWithdrawAmountForInVAccBlocked(){
		bankingServices.getAccountDetails(111,1).setStatus("Blocked");
		bankingServices.withdrawAmount(111,1,1000,1234);
	}
	
	@Test
	public void testOnFundTransferForVCustomerIDFromVAccNoFromVCustomerIDToVAccNoToVAmountVPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException {
		assertTrue(bankingServices.fundTransfer(111,1,112,1, 1000,1234));
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testOnFundTransferForInVCustomerIDFromVAccNoFromVCustomerIDToVAccNoToVAmountVPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException {
		bankingServices.fundTransfer(-100,1,112,1, 1000,1234);
	}
	
	@Test(expected=AccountNotFoundException.class)
	public void testOnFundTransferForVCustomerIDFromInVAccNoFromVCustomerIDToVAccNoToVAmountVPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException {
		bankingServices.fundTransfer(111, -20,112,1, 1000,1234);
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testOnFundTransferForVCustomerIDFromVAccNoFromInVCustomerIDToVAccNoToVAmountVPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException {
		bankingServices.fundTransfer(111,1, -100,1, 1000,1234);
	}
	
	@Test(expected=AccountNotFoundException.class)
	public void testOnFundTransferForVCustomerIDFromVAccNoFromVCustomerIDToInVAccNoToVAmountVPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException {
		bankingServices.fundTransfer(111,1,112, -20,1000,1234);
	}
	
	@Test(expected=InvalidAmountException.class)
	public void testOnFundTransferForVCustomerIDFromVAccNoFromVCustomerIDToVAccNoToInVAmountVPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException {
		bankingServices.fundTransfer(111,1,112,1, -50,1234);
	}
	
	@Test(expected=InsufficientAmountException.class)
	public void testOnFundTransferForVCustomerIDFromVAccNoFromVCustomerIDToVAccNoToInSuffAmountVPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException {
		bankingServices.fundTransfer(111,1,112,1,30000,1234);
	}
	
	@Test(expected=InvalidPinNumberException.class)
	public void testOnFundTransferForVCustomerIDFromVAccNoFromVCustomerIDToVAccNoToVAmountInVPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException {
		bankingServices.fundTransfer(111,1,112,1,1000, -100);
	}
	
	@Test(expected=AccountBlockedException.class)
	public void testOnFundTransferForFirstInvalidAccType(){
		bankingServices.getAccountDetails(111,1).setStatus("Blocked");
		bankingServices.fundTransfer(111,1,112,1,1000,1234);
	}
	
	@Test(expected=AccountBlockedException.class)
	public void testOnFundTransferForSecondInvalidAccType(){
		bankingServices.getAccountDetails(112,1).setStatus("Blocked");
		bankingServices.fundTransfer(112,1,111,1,1000,1234);
	}
		
	@Test
	public void testOnBalanceEnquiryForVCustomerIDVAccNoVPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InvalidPinNumberException {
		assertEquals(10000,bankingServices.showBalance(111,1,1234));
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testOnBalanceEnquiryForInVCustomerIDVAccNoVPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InvalidPinNumberException {
		bankingServices.showBalance(20,1,1234);
	}
	
	@Test(expected=AccountNotFoundException.class)
	public void testOnBalanceEnquiryForVCustomerIDInVAccNoVPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InvalidPinNumberException {
		bankingServices.showBalance(111,40,1234);
	}
	
	@Test(expected=InvalidPinNumberException.class)
	public void testOnBalanceEnquiryForVCustomerIDVAccNoInVPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InvalidPinNumberException {
		bankingServices.showBalance(111,1,0);
	}
	
	@Test(expected=AccountBlockedException.class)
	public void testOnBalanceEnquiryForInvalidAccType(){
		bankingServices.getAccountDetails(111,1).setStatus("Blocked");
		bankingServices.showBalance(111,1,1234);
	}
		
	@Test
	public void testOnChangeAccountPinForVCustomerIDVAccNoVOldPinVNewPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InvalidPinNumberException {
		bankingServices.changeAccountPin(111,1,1234, 1001);
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testOnChangeAccountPinForInVCustomerIDVAccNoVOldPinVNewPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InvalidPinNumberException {
		bankingServices.changeAccountPin(20,1,1234, 1001);
	}
	
	@Test(expected=AccountNotFoundException.class)
	public void testOnChangeAccountPinForVCustomerIDInVAccNoVOldPinVNewPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InvalidPinNumberException {
		bankingServices.changeAccountPin(111, 20,1234, 1001);
	}
	
	@Test(expected=InvalidPinNumberException.class)
	public void testOnChangeAccountPinForVCustomerIDInVAccNoInVOldPinVNewPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InvalidPinNumberException {
		bankingServices.changeAccountPin(111,1,-20,1001);
	}
	
	@Test(expected=InvalidPinNumberException.class)
	public void testOnChangeAccountPinForVCustomerIDInVAccNoInVOldPinInVNewPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, InvalidPinNumberException {
		bankingServices.changeAccountPin(111,1,1234,-20);
	}
			
	@Test
	public void testOnAccountStatusForValidCustomerIDValidAccountNo() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException {
		assertEquals("Active",bankingServices.accountStatus(111,1));
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testOnAccountStatusForInValidCustomerIDValidAccountNo() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException {
		bankingServices.accountStatus(-300, accountNo);
	}
	
	@Test(expected=AccountNotFoundException.class)
	public void testOnAccountStatusForValidCustomerIDInValidAccountNo() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException {
		bankingServices.accountStatus(customerId,-250);
	}
	
	@Test
	public void testonGetAccountAllTransactionForVCustomerIdVAccNo() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException {
		Transaction transaction2 = new Transaction( 5000, "Deposit");
		transaction2.setTransactionId(2);
		HashMap<Integer,Transaction> transactionList = new HashMap<>();
		
		Account account=new Account(1234, 0, "Savings", "Active",10000,1,transactionList);
		account.transactions.put(1, transaction2);
	
		assertEquals(transactionList,getAccountAllTransaction(111,1));
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testonGetAccountAllTransactionForInVCustomerIdVAccNo() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException {
		bankingServices.getAccountAllTransaction(20,1);

	}
	
	@Test(expected=AccountNotFoundException.class)
	public void testonGetAccountAllTransactionForVCustomerIdInVAccNo() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException {
		bankingServices.getAccountAllTransaction(111, 20);
	}
	
	@Test
	public void testOnGetAccountDetailsForVCustomerIDVAccNo() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException {
		Transaction transaction2 = new Transaction( 5000, "Deposit");
		transaction2.setTransactionId(2);
		HashMap<Integer,Transaction> transactionList = new HashMap<>();
		
		Account account=new Account(1234, 0, "Savings", "Active",10000,1,transactionList);
		account.transactions.put(1, transaction2);
	
		assertEquals(account,bankingServices.getAccountDetails(111,1));

	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testOnGetAccountDetailsForInVCustomerIDVAccNo() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException {
		bankingServices.getAccountDetails(20, 1);
	}
	
	@Test(expected=AccountNotFoundException.class)
	public void testOnGetAccountDetailsForVCustomerIDInVAccNo() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException {
		bankingServices.getAccountDetails(111, -10);
	}
	
	@Test
	public void testOnGetCustomerAllAccountDetailsForVCustomerID() throws BankingServicesDownException, CustomerNotFoundException, InvalidAmountException, InvalidAccountTypeException {
		Account account=new Account(1234, 0, "Savings", "Active",10000,1,transactionList);
		
		bankingServices.getcustomerAllAccountDetails(111);
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testOnGetCustomerAllAccountDetailsForInVCustomerID() throws BankingServicesDownException, CustomerNotFoundException, InvalidAmountException, InvalidAccountTypeException {
		int customerId=bankingServices.acceptCustomerDetails("abhi", "ch", "abhi@abcd.com", "a1", "hyd", "tel",123456, "pune", "mhr",147852);
		long accountNo=bankingServices.openAccount(customerId,"Savings", 10000);
		bankingServices.getcustomerAllAccountDetails(20);
	}
	
	@Test
	public void testOnGetCustomerDetailsForVCustomerID() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException {
		assertEquals(BankingDAOServicesImpl.customers.get(customerId),bankingServices.getCustomerDetails(customerId));
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testOnGetCustomerDetailsForInVCustomerID() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException {
		bankingServices.getCustomerDetails(20);
	}
	
	@Test
	public void testOnCloseAccountForVCustomerIDVAccNo() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException{
		aasertTrue(bankingServices.closeAccount(111,1));
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testOnCloseAccountForInVCustomerIDVAccNo() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException{
		bankingServices.closeAccount(20,1);
	}
	
	@Test(expected=AccountNotFoundException.class)
	public void testOnCloseAccountForVCustomerIDInVAccNo() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException{
		bankingServices.closeAccount(111, 10);
	}
	
	@After
	public void  tearDownMockData() {
		BankingDAOServicesImpl.customers.clear();
		BankingUtility.CUSTOMER_ID_COUNTER=111;
		BankingUtility.ACCOUNT_ID_COUNTER=1;
		BankingUtility.TRANSACTION_ID_COUNTER=1;		
	}
	
	@AfterClass
	public static void tearDownTestEnv() {
		bankingServices=null;
		bankingDAOServices=null;
	}
}
