package com.cg.payroll.daoservices;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.utility.PayrollUtility;
public class PayrollDAOServicesImpl implements PayrollDAOServices{
	
	public static HashMap<Integer, Associate> associates=new HashMap<>();
	public static int A=0;
	public static List<Associate> list;
	
	@Override
	public int insertAssociate(Associate associate) {
		associates.put(PayrollUtility.ASSOCIATE_ID_COUNTER, associate);
		associate.setAssociateID(PayrollUtility.ASSOCIATE_ID_COUNTER++);
		return associate.getAssociateID();
	}
	@Override
	public boolean updateAssociate(Associate associate) {
		if(associates.containsKey(associate.getAssociateID())==true) {
			associates.put(associate.getAssociateID(), associate);
			associate.setAssociateID(associate.getAssociateID());
			return true;
		}
		
		return false;
	}
	@Override
	public boolean deleteAssociate(int associateID) {
		associates.remove(associateID);
		return true;
	}
	@Override
	public Associate getAssociate(int associateID) {
		return associates.get(associateID);
	}
	@Override
	public List<Associate> getAssociates() {
		List<Associate> associateList = new ArrayList<Associate>(associates.values());
		return associateList;
	}
	public static void doSerialization(File file) throws IOException {
		try(ObjectOutputStream dest=new ObjectOutputStream(new FileOutputStream(file))){
			 ArrayList<Integer> sortedKeys =
	                    new ArrayList<Integer>(associates.keySet());
			 Collections.sort(sortedKeys); 
			 System.out.println(sortedKeys);
			 HashMap<Integer, Associate> sortedAssociates = new HashMap<Integer, Associate>();
			 for (int i : sortedKeys) {
				 sortedAssociates.put(i,associates.get(i));
			 }
			 System.out.println(Collections.singletonList(sortedAssociates));
			dest.writeObject(sortedAssociates);
			//System.out.println(sortedAssociates);
		}
	}
	public static void doDeSerialization(File file) throws FileNotFoundException, IOException, ClassNotFoundException {
		try(ObjectInputStream src=new ObjectInputStream(new FileInputStream(file))) {
			HashMap<Integer,Associate> associate1=(HashMap<Integer,Associate>)src.readObject();
			System.out.println(Collections.singletonList(associate1));
			//associates=associate1;
			
		/*	list = new ArrayList<Associate>(associate1.values());
			System.out.println(list.size());
			for (Associate associate : list) {
				System.out.println(associate);	*/
			}
			//A=list.get(0).getAssociateID();
			//PayrollUtility.ASSOCIATE_ID_COUNTER=A+1;
			
		}
}
