package com.cg.payroll.services;
import java.util.List;

import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.utility.PayrollUtility;
import com.cg.payroll.daoservices.PayrollDAOServices;
public class PayrollServicesImpl implements PayrollServices{

	PayrollDAOServices daoServices = new PayrollDAOServicesImpl();
	public PayrollServicesImpl() {

	}

	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#acceptAssociateDetails(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, int, int, int, int, int, java.lang.String, java.lang.String)
	 */
	@Override
	public int acceptAssociateDetails(String firstName, String lastName,
			String emailId,String department, String designation, String pancard,
			int yearlyInvestmentUnder80C,int basicSalary,int epf,int companyPf,int accountNumber
			,String bankName, String ifscCode) throws PayrollServicesDownException{
		/*Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode));
			daoServices.insertAssociate(associate);
				return associate.getAssociateID();*/
		
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
	}
	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#calculateNetSalary(int)
	 */
	@Override
	public int calculateNetSalary(int associateId)throws AssociateDetailsNotFoundException, PayrollServicesDownException{
		Associate associate=this.getAssociateDetails(associateId);
		
		int taxAmount=0;
		if(associate!=null){
			associate.getSalary().setPersonalAllowance((int)30*associate.getSalary().getBasicSalary()/100);
			associate.getSalary().setConveyenceAllowance((int)20*associate.getSalary().getBasicSalary()/100);
			associate.getSalary().setOtherAllowance((int)10*associate.getSalary().getBasicSalary()/100);
			associate.getSalary().setHra((int)(25/10)*associate.getSalary().getBasicSalary()/100);
			associate.getSalary().setGratuity((int)50*associate.getSalary().getBasicSalary()/100);
			associate.getSalary().setGrossSalary(associate.getSalary().getPersonalAllowance()+associate.getSalary().getBasicSalary()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getHra()+associate.getSalary().getCompanyPf());
			int annualSalary=associate.getSalary().getGrossSalary()*12;
			int taxableSalary=annualSalary;
			int nonTaxableSalary=associate.getYearlyInvestmentUnder80C()+(associate.getSalary().getEpf()*12)+(associate.getSalary().getCompanyPf()*12);
			if(nonTaxableSalary>150000)
				nonTaxableSalary=150000;
			if(taxableSalary<=250000){
				taxAmount=0;
			}	
			else if(taxableSalary>250000 && taxableSalary<=500000){
				taxableSalary=taxableSalary-250000-nonTaxableSalary;
				if(taxableSalary<0)
					taxAmount=0;
				else
					taxAmount=taxableSalary*10/100;	
			}
			else if (taxableSalary>500000 && taxableSalary<=1000000){
				int taxSlab2=(500000-250000-nonTaxableSalary)*10/100;
				taxAmount=((taxableSalary-500000)*20/100)+taxSlab2;	
			}
			else if (taxableSalary>1000000){
				int taxSlab2=(500000-250000-nonTaxableSalary)*10/100;
				int taxSlab3=(500000)*20/100;
				taxAmount=((taxableSalary-1000000)*30/100)+taxSlab3+taxSlab2;	
			}
			associate.getSalary().setMonthlyTax((int)taxAmount/12);
			associate.getSalary().setNetSalary((int)(((annualSalary-taxAmount)/12)-associate.getSalary().getCompanyPf()-associate.getSalary().getEpf()));
			return associate.getSalary().getNetSalary() ;
		}
		return 0;
	}
	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#getAssociateDetails(int)
	 */
	@Override
	public Associate getAssociateDetails(int associateID)  throws AssociateDetailsNotFoundException,PayrollServicesDownException{
		Associate associate =daoServices.getAssociate(associateID);
		if(associate==null)
			throw new AssociateDetailsNotFoundException("Associate details of  "+associateID+" not found");
		return associate;
	}
	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#getAllAssociatesDetails()
	 */
	@Override
	public List<Associate> getAllAssociatesDetails() throws PayrollServicesDownException {
		return daoServices.getAssociates();
	}

	@Override
	public boolean updateAssociateDetails(Associate associate) throws AssociateDetailsNotFoundException,PayrollServicesDownException {
		if(this.getAllAssociatesDetails().contains(associate.getAssociateID())!=true) throw new AssociateDetailsNotFoundException("AssociateID Entered is:  "+associate.getAssociateID()+",Please Enter Valid AssocaiteID.");
		return daoServices.updateAssociate(associate);
	}

	

}
