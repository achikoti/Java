package com.cg.payroll.utility;

import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;


import com.cg.payroll.daoservices.*;
public class PayrollUtility {
	public static int ASSOCIATE_ID_COUNTER=111;
	//public static int ASSOCIATE_IDX_COUNTER=0;
		
}
	/*public boolean strCheckAnno(String str) {
		 for (int i=0;i<str.length();i++)
             if (str.charAt(i)=='@')
            	 return true;
		 return false;
	}
	
	public boolean strCheckDot(String str) {
		System.out.println(str.charAt(0));
		 for (int i=0;i<str.length();i++)
            if (str.charAt(i)=='.')
           	 return true;
		 return false;
	}
	
	public boolean strCheckLowerCase(String str) {
		 for (int i=0;i<str.length();i++)
	            if (str.charAt(i)>='a'&&str.charAt(i)<='z')
	            	return true;	
		return false;
	}
	
	public boolean strCheckUpperCase(String str) {
		 for (int i=0;i<str.length();i++)
	            if (str.charAt(i)>='A'&&str.charAt(i)<='Z')
	            	return true;	
		return false;
	}
	
	public boolean strCheckNumerical(String str) {
		 for (int i=0;i<str.length();i++)
	            if (str.charAt(i)>='0'&&str.charAt(i)<='9')
	            	return true;	
		return false;
	}*/


