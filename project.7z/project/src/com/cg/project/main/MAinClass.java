package com.cg.project.main;

import com.cg.project.beans.CEmployee;
import com.cg.project.beans.Developer;
import com.cg.project.beans.Employee;
import com.cg.project.beans.PEmployee;
import com.cg.project.beans.SalesManager;

public class MAinClass {

	public static void main(String[] args) {
		/*Employee employee=new Employee("abhi", "ch", 1234, 150000);
		employee.calculateTotalSalary();
		System.out.println(employee.toString());
		
		PEmployee pEmployee=new PEmployee("yosh", "a", 1235, 160000);
		pEmployee.calculateTotalSalary();
		System.out.println(pEmployee.toString());
		
		CEmployee cEmployee=new CEmployee("vijay", "a", 1236, 600);
		cEmployee.contractSign();
		cEmployee.calculateTotalSalary();
		System.out.println(cEmployee.toString());
		
		Developer developer=new Developer("abhinav", "chikoti", 1237, 200000, 3);
		developer.projectsDone();
		developer.calculateTotalSalary();
		System.out.println(developer.toString());
		
		SalesManager salesmanager=new SalesManager("akash", "gupta", 1238, 250000, 36000);
		salesmanager.doASale();
		salesmanager.calculateTotalSalary();
		System.out.println(salesmanager.toString());*/
		
	/*Employee employee = new PEmployee("abhi", "ch", 1235, 350000);
	employee.calculateTotalSalary();
	//System.out.println(employee.toString());
	System.out.println(employee);*/
		
		//Employee employee = new PEmployee("abhi", "ch", 1235, 350000);//dynamic binding
		//Employee employee=new CEmployee("vijay", "a", 1236, 600);//dynamic binding
		//Employee employee=new Developer("abhinav", "chikoti", 1237, 200000, 3);//dynamic binding
		Employee employee=new SalesManager("akash", "gupta", 1238, 250000, 36000);//dynamic binding
		//Employee employee =new Employee("abhi", "ch", 1234, 150000);//static Binding
		callForSalaryCalculation(employee);

	}
	//dynamic polymorphism reference
	public static void callForSalaryCalculation (Employee employee) {
		/*CEmployee ce=(CEmployee)employee;
		employee.contractSign();*/                                    //DownCasting
		/*Developer dev=(Developer)employee;
		dev.projectsDone();*/                                            //DownCasting
		SalesManager sm= (SalesManager)employee;
		sm.doASale();                                                         //Down Casting
		System.out.println(employee.calculateTotalSalary());
	}

}
