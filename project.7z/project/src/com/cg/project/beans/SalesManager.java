package com.cg.project.beans;

public final class SalesManager extends PEmployee{
	private int salesAmt,comission;

	public SalesManager() {
		super();
	}

	public SalesManager(String firstname, String lastName, int employeeId, int basicSalary,int salesAmt) {
		super(firstname, lastName, employeeId, basicSalary);
		this.salesAmt=salesAmt;
	}
	

	public int getSalesAmt() {
		return salesAmt;
	}
	
	public void doASale() {
		System.out.println("Sales has done");
	}
	public void setSalesAmt(int salesAmt) {
		this.salesAmt = salesAmt;
	}
	
	@Override
	public String toString() {
		return "SalesManager "+super.toString()+" [salesAmt=" + salesAmt + ", comission=" + comission + "]";
	}

	public int getComission() {
		return comission;
	}

	public void setComission(int comission) {
		this.comission = comission;
	}

	@Override
	public int calculateTotalSalary() {
		super.calculateTotalSalary();
		this.comission=1*this.salesAmt/100;
		return (getHra()+getTa()+getDa()+getBasicSalary()+this.comission);
	}
	
	
	

}
