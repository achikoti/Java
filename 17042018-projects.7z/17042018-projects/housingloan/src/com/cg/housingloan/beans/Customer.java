package com.cg.housingloan.beans;

public class Customer {

}
