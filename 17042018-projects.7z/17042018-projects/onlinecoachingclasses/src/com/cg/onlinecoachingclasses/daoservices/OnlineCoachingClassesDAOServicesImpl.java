package com.cg.onlinecoachingclasses.daoservices;

public class OnlineCoachingClassesDAOServicesImpl {

}
