package com.cg.onlinecoachingclasses.main;

import com.cg.onlinecoachingclasses.beans.Address;
import com.cg.onlinecoachingclasses.beans.Admission;
import com.cg.onlinecoachingclasses.beans.Coaching;
import com.cg.onlinecoachingclasses.beans.Discount;
import com.cg.onlinecoachingclasses.beans.Payment;
import com.cg.onlinecoachingclasses.beans.Student;

public class MainClass {

	public static void main(String[] args) {
		Student student=studentSearch();
		if(student!=null)
			System.out.println("Details Found");
		else
			System.out.println("No Details Found");

	}
	public static Student studentSearch() {
		Student studentList[]=new Student[4];
		studentList[0]=new Student(101, "satish", "+919875684250","satish@abcd.com",25893, new Address("pune", "mhr", "india", 500010), new Coaching("fast-track", "java", "01/04/2018", "30/06/2018", 91, 50000),new Discount("halfd", "25/03/2018", "half", 25000),new Admission("01/04/2018", "paid", 25000,0),new Payment("cash", "paid", "20/03/2018",25000));
		studentList[1]=new Student(102, "abhi", "+919875684251","abhi@abcd.com",36985,new Address("pune", "mhr", "india", 500010), new Coaching("fast-track", "full-stack developer", "01/04/2018", "30/06/2018", 91, 60000),new Discount("halfd", "25/03/2018", "half", 30000),new Admission("01/04/2018", "paid", 30000,0),new Payment("cash", "paid", "22/03/2018",30000));
		studentList[2]=new Student(103, "yosh", "+919875684252","yosh@abcd.com",14785,new Address("pune", "mhr", "india", 500010), new Coaching("fast-track", "full-stack developer", "01/04/2018", "30/06/2018", 91, 60000),new Discount("halfd", "25/03/2018", "half", 30000),new Admission("01/04/2018", "paid", 30000,0),new Payment("cash", "paid", "21/03/2018",30000));
		for(Student students:studentList) {
			if(students!=null&&students.getName()=="abhi"&&students.getAdmission().getFeesAmount()==30000)
				return students;
		}
		return null;
	}

}
