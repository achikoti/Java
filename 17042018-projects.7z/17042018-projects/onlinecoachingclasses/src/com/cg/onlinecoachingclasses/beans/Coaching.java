package com.cg.onlinecoachingclasses.beans;

public class Coaching {
	private String typeOfCourse,nameOfCourse,startingDate,endingDate;
	private int noOfDays,costOfCourse;
	public Coaching() {
		super();
	}
	public Coaching(String typeOfCourse, String nameOfCourse, String startingDate, String endingDate, int noOfDays,
			int costOfCourse) {
		super();
		this.typeOfCourse = typeOfCourse;
		this.nameOfCourse = nameOfCourse;
		this.startingDate = startingDate;
		this.endingDate = endingDate;
		this.noOfDays = noOfDays;
		this.costOfCourse = costOfCourse;
	}
	public String getTypeOfCourse() {
		return typeOfCourse;
	}
	public void setTypeOfCourse(String typeOfCourse) {
		this.typeOfCourse = typeOfCourse;
	}
	public String getNameOfCourse() {
		return nameOfCourse;
	}
	public void setNameOfCourse(String nameOfCourse) {
		this.nameOfCourse = nameOfCourse;
	}
	public String getStartingDate() {
		return startingDate;
	}
	public void setStartingDate(String startingDate) {
		this.startingDate = startingDate;
	}
	public String getEndingDate() {
		return endingDate;
	}
	public void setEndingDate(String endingDate) {
		this.endingDate = endingDate;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	public int getCostOfCourse() {
		return costOfCourse;
	}
	public void setCostOfCourse(int costOfCourse) {
		this.costOfCourse = costOfCourse;
	}
	

}
