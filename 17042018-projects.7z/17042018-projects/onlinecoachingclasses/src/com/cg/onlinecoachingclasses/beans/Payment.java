package com.cg.onlinecoachingclasses.beans;

public class Payment {
	private String typeOfPayment,paymentStatus,paymentDate;
	private int paymentAmount;
	public Payment() {
		super();
	}
	public Payment(String typeOfPayment, String paymentStatus, String paymentDate, int paymentAmount) {
		super();
		this.typeOfPayment = typeOfPayment;
		this.paymentStatus = paymentStatus;
		this.paymentDate = paymentDate;
		this.paymentAmount = paymentAmount;
	}
	public String getTypeOfPayment() {
		return typeOfPayment;
	}
	public void setTypeOfPayment(String typeOfPayment) {
		this.typeOfPayment = typeOfPayment;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public String getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}
	public int getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(int paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	
	
	

}
