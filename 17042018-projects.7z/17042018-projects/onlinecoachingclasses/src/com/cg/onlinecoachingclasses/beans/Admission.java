package com.cg.onlinecoachingclasses.beans;

public class Admission {
	private String dateOfAdmission,feesStatus;
	private int feesAmount,remainigBalance;
	public Admission() {
		super();
	}
	public Admission(String dateOfAdmission, String feesStatus, int feesAmount, int remainigBalance) {
		super();
		this.dateOfAdmission = dateOfAdmission;
		this.feesStatus = feesStatus;
		this.feesAmount = feesAmount;
		this.remainigBalance = remainigBalance;
	}
	public String getDateOfAdmission() {
		return dateOfAdmission;
	}
	public void setDateOfAdmission(String dateOfAdmission) {
		this.dateOfAdmission = dateOfAdmission;
	}
	public String getFeesStatus() {
		return feesStatus;
	}
	public void setFeesStatus(String feesStatus) {
		this.feesStatus = feesStatus;
	}
	public int getFeesAmount() {
		return feesAmount;
	}
	public void setFeesAmount(int feesAmount) {
		this.feesAmount = feesAmount;
	}
	public int getRemainigBalance() {
		return remainigBalance;
	}
	public void setRemainigBalance(int remainigBalance) {
		this.remainigBalance = remainigBalance;
	}
	
	
	

}
