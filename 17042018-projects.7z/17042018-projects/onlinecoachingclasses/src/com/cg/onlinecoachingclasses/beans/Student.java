package com.cg.onlinecoachingclasses.beans;

public class Student {
	private int studentID,adharNo;
	private String name,mobileNo,emailID;
	private Address address;
	private Coaching coaching;
	private Discount discount;
	private Admission admission;
	private Payment payment;
	public Student() {
		super();
	}
	public Student(int studentID, String name, String mobileNo,String emailID,int adharNo, Address address, Coaching coaching,
			Discount discount, Admission admission, Payment payment) {
		super();
		this.studentID = studentID;
		this.name = name;
		this.mobileNo = mobileNo;
		this.emailID=emailID;
		this.adharNo=adharNo;
		this.address = address;
		this.coaching = coaching;
		this.discount = discount;
		this.admission = admission;
		this.payment = payment;
	}
	public int getStudentID() {
		return studentID;
	}
	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public int getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(int adharNo) {
		this.adharNo = adharNo;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Coaching getCoaching() {
		return coaching;
	}
	public void setCoaching(Coaching coaching) {
		this.coaching = coaching;
	}
	public Discount getDiscount() {
		return discount;
	}
	public void setDiscount(Discount discount) {
		this.discount = discount;
	}
	public Admission getAdmission() {
		return admission;
	}
	public void setAdmission(Admission admission) {
		this.admission = admission;
	}
	public Payment getPayment() {
		return payment;
	}
	public void setPayment(Payment payment) {
		this.payment = payment;
	}
	
	

}
