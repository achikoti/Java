package com.cg.officemanagerlms.beans;

public class Employee {

}
