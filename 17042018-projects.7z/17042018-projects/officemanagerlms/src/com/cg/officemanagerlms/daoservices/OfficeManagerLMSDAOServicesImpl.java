package com.cg.officemanagerlms.daoservices;

public class OfficeManagerLMSDAOServicesImpl {

}
