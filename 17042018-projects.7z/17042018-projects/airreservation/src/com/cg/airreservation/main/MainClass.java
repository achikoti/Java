package com.cg.airreservation.main;

import com.cg.airreservation.beans.Cancellation;
import com.cg.airreservation.beans.ConnectingFlights;
import com.cg.airreservation.beans.Food;
import com.cg.airreservation.beans.JourneyDetails;
import com.cg.airreservation.beans.Passenger;
import com.cg.airreservation.beans.Transaction;

public class MainClass {

	public static void main(String[] args) {
		JourneyDetails journeydetails=journeydetailsSearch();
		if(journeydetails!=null)
			System.out.println("Details Found");
		else
			System.out.println("No Details Found");

	}
	public static JourneyDetails journeydetailsSearch() {
		JourneyDetails journeydetailsList[]=new JourneyDetails[4];
		journeydetailsList[0]= new JourneyDetails(101, "pune", "hyd", "21:00:00:00", "economic", "01/04/2018", "01/04/2018", new Food("applied", "veg"), new Passenger("satish", "mahajan", "+919876543210", "satish@abcd.com", 1234567),new Transaction("internet banking", "success", "30/03/2018", 50000),new ConnectingFlights("available", "mumbai"),new Cancellation("half", "31/03/2018", 40));
		journeydetailsList[1]= new JourneyDetails(102, "chn", "hyd", "21:00:00:00", "economic", "01/04/2018", "01/04/2018", new Food("applied", "veg"), new Passenger("abhi", "c", "+919876543211", "abhi@abcd.com", 1234566),new Transaction("internet banking", "success", "30/03/2018", 50000),new ConnectingFlights("available", "mumbai"),new Cancellation("half", "31/03/2018", 40));
		journeydetailsList[2]= new JourneyDetails(103, "del", "hyd", "21:00:00:00", "economic", "01/04/2018", "01/04/2018", new Food("applied", "non-veg"), new Passenger("yosh", "a", "+919876543212", "yosh@abcd.com", 1234565),new Transaction("internet banking", "success", "30/03/2018", 50000),new ConnectingFlights("available", "mumbai"),new Cancellation("half", "31/03/2018", 40));
		for(JourneyDetails journeydetails:journeydetailsList) {
			if(journeydetails!=null&&journeydetails.getTicketID()==103&&journeydetails.getFood().getTypeOfFood()=="non-veg")
				return journeydetails;
		}
		return null;
	}

}
