package com.cg.airreservation.daoservices;

public class AirReservationDAOServicesImpl {

}
