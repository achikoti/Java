package com.cg.airreservation.beans;

public class Ticket {
	private String fromPlace,toPlace,timeofDeparture,timeOfArrival,typeOfClass,fromDate,toDate,gateNo;
	private float ticketCost;
	private int seatNo,ticketID;
	private Transaction transaction;
	private Cancellation cancellation;
	public Ticket() {
		super();
	}
	public Ticket(String fromPlace, String toPlace, String timeofDeparture, String timeOfArrival, String typeOfClass,
			String fromDate, String toDate, String gateNo, float ticketCost, int seatNo, int ticketID,
			Transaction transaction, Cancellation cancellation) {
		super();
		this.fromPlace = fromPlace;
		this.toPlace = toPlace;
		this.timeofDeparture = timeofDeparture;
		this.timeOfArrival = timeOfArrival;
		this.typeOfClass = typeOfClass;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.gateNo = gateNo;
		this.ticketCost = ticketCost;
		this.seatNo = seatNo;
		this.ticketID = ticketID;
		this.transaction = transaction;
		this.cancellation = cancellation;
	}
	public String getFromPlace() {
		return fromPlace;
	}
	public void setFromPlace(String fromPlace) {
		this.fromPlace = fromPlace;
	}
	public String getToPlace() {
		return toPlace;
	}
	public void setToPlace(String toPlace) {
		this.toPlace = toPlace;
	}
	public String getTimeofDeparture() {
		return timeofDeparture;
	}
	public void setTimeofDeparture(String timeofDeparture) {
		this.timeofDeparture = timeofDeparture;
	}
	public String getTimeOfArrival() {
		return timeOfArrival;
	}
	public void setTimeOfArrival(String timeOfArrival) {
		this.timeOfArrival = timeOfArrival;
	}
	public String getTypeOfClass() {
		return typeOfClass;
	}
	public void setTypeOfClass(String typeOfClass) {
		this.typeOfClass = typeOfClass;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getGateNo() {
		return gateNo;
	}
	public void setGateNo(String gateNo) {
		this.gateNo = gateNo;
	}
	public float getTicketCost() {
		return ticketCost;
	}
	public void setTicketCost(float ticketCost) {
		this.ticketCost = ticketCost;
	}
	public int getSeatNo() {
		return seatNo;
	}
	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}
	public int getTicketID() {
		return ticketID;
	}
	public void setTicketID(int ticketID) {
		this.ticketID = ticketID;
	}
	public Transaction getTransaction() {
		return transaction;
	}
	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}
	public Cancellation getCancellation() {
		return cancellation;
	}
	public void setCancellation(Cancellation cancellation) {
		this.cancellation = cancellation;
	}
	
}
