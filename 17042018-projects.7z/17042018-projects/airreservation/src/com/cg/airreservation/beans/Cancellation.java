package com.cg.airreservation.beans;

public class Cancellation {
	private int ticketID,cancellationCharges,percentageOfCancellationPerDayAfterDeadline;
	private String deadlineDate;
	public Cancellation() {
		super();
	}
	public Cancellation(int ticketID, int cancellationCharges, int percentageOfCancellationPerDayAfterDeadline,
			String deadlineDate) {
		super();
		this.ticketID = ticketID;
		this.cancellationCharges = cancellationCharges;
		this.percentageOfCancellationPerDayAfterDeadline = percentageOfCancellationPerDayAfterDeadline;
		this.deadlineDate = deadlineDate;
	}
	public int getTicketID() {
		return ticketID;
	}
	public void setTicketID(int ticketID) {
		this.ticketID = ticketID;
	}
	public int getCancellationCharges() {
		return cancellationCharges;
	}
	public void setCancellationCharges(int cancellationCharges) {
		this.cancellationCharges = cancellationCharges;
	}
	public int getPercentageOfCancellationPerDayAfterDeadline() {
		return percentageOfCancellationPerDayAfterDeadline;
	}
	public void setPercentageOfCancellationPerDayAfterDeadline(int percentageOfCancellationPerDayAfterDeadline) {
		this.percentageOfCancellationPerDayAfterDeadline = percentageOfCancellationPerDayAfterDeadline;
	}
	public String getDeadlineDate() {
		return deadlineDate;
	}
	public void setDeadlineDate(String deadlineDate) {
		this.deadlineDate = deadlineDate;
	}
	
	
	
}
