package com.cg.airreservation.beans;

public class Passenger {
	private  String firstNamelastName;
	private long mobileNo,adharNo;
	private int age;
	private JourneyDetails journeydetails[];

	public Passenger() {
		super();
	}

	public Passenger(String firstNamelastName, long mobileNo, long adharNo, int age, JourneyDetails[] journeydetails) {
		super();
		this.firstNamelastName = firstNamelastName;
		this.mobileNo = mobileNo;
		this.adharNo = adharNo;
		this.age = age;
		this.journeydetails = journeydetails;
	}

	public String getFirstNamelastName() {
		return firstNamelastName;
	}

	public void setFirstNamelastName(String firstNamelastName) {
		this.firstNamelastName = firstNamelastName;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public long getAdharNo() {
		return adharNo;
	}

	public void setAdharNo(long adharNo) {
		this.adharNo = adharNo;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public JourneyDetails[] getJourneydetails() {
		return journeydetails;
	}

	public void setJourneydetails(JourneyDetails[] journeydetails) {
		this.journeydetails = journeydetails;
	}
	
}

	

	