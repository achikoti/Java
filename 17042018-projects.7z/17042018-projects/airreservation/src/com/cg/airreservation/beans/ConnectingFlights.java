package com.cg.airreservation.beans;

public class ConnectingFlights {
	private String connectingFlightsAvailability,nameOfConnectingstations;

	public ConnectingFlights() {
		super();
	}

	public ConnectingFlights(String connectingFlightsAvailability, String nameOfConnectingstations) {
		super();
		this.connectingFlightsAvailability = connectingFlightsAvailability;
		this.nameOfConnectingstations = nameOfConnectingstations;
	}

	public String getConnectingFlightsAvailability() {
		return connectingFlightsAvailability;
	}

	public void setConnectingFlightsAvailability(String connectingFlightsAvailability) {
		this.connectingFlightsAvailability = connectingFlightsAvailability;
	}

	public String getNameOfConnectingstations() {
		return nameOfConnectingstations;
	}

	public void setNameOfConnectingstations(String nameOfConnectingstations) {
		this.nameOfConnectingstations = nameOfConnectingstations;
	}

	
}
