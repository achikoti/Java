package com.cg.airreservation.beans;

public class Flight {
	private String flightName,flightCode,boardingPoint,endingPoint,startingTime,reachingTime,typeOfClass;
	private Ticket ticket;
	public Flight() {
		super();
	}
	public Flight(String flightName, String flightCode, String boardingPoint, String endingPoint, String startingTime,
			String reachingTime, String typeOfClass, Ticket ticket) {
		super();
		this.flightName = flightName;
		this.flightCode = flightCode;
		this.boardingPoint = boardingPoint;
		this.endingPoint = endingPoint;
		this.startingTime = startingTime;
		this.reachingTime = reachingTime;
		this.typeOfClass = typeOfClass;
		this.ticket = ticket;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getFlightCode() {
		return flightCode;
	}
	public void setFlightCode(String flightCode) {
		this.flightCode = flightCode;
	}
	public String getBoardingPoint() {
		return boardingPoint;
	}
	public void setBoardingPoint(String boardingPoint) {
		this.boardingPoint = boardingPoint;
	}
	public String getEndingPoint() {
		return endingPoint;
	}
	public void setEndingPoint(String endingPoint) {
		this.endingPoint = endingPoint;
	}
	public String getStartingTime() {
		return startingTime;
	}
	public void setStartingTime(String startingTime) {
		this.startingTime = startingTime;
	}
	public String getReachingTime() {
		return reachingTime;
	}
	public void setReachingTime(String reachingTime) {
		this.reachingTime = reachingTime;
	}
	public String getTypeOfClass() {
		return typeOfClass;
	}
	public void setTypeOfClass(String typeOfClass) {
		this.typeOfClass = typeOfClass;
	}
	public Ticket getTicket() {
		return ticket;
	}
	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}
	
}