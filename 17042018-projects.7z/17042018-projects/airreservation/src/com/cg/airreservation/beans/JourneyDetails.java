package com.cg.airreservation.beans;

public class JourneyDetails {
	private String from,to,dateOfJourney;
	private Flight flight[];
	public JourneyDetails() {
		super();
	}
	public JourneyDetails(String from, String to, String dateOfJourney, Flight[] flight) {
		super();
		this.from = from;
		this.to = to;
		this.dateOfJourney = dateOfJourney;
		this.flight = flight;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getDateOfJourney() {
		return dateOfJourney;
	}
	public void setDateOfJourney(String dateOfJourney) {
		this.dateOfJourney = dateOfJourney;
	}
	public Flight[] getFlight() {
		return flight;
	}
	public void setFlight(Flight[] flight) {
		this.flight = flight;
	}
	
}
	