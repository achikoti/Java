package com.cg.banking.main;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class MainClass {

	public static void main(String[] args) {
		Customer customer=customersearch();
		if(customer!=null) 
			System.out.println("Details Found");
		else
			System.out.println("No Details Found");
		/*for(int i=0;i<5;i++) {
			customerList[i]=new Customer[3];
			for(int j=0;j<3;j++) {
				customerList[i][j]=new Customer();
			}
		}*/
		
		
		/*Account account =new Account(123, 2350, "sav");
		Address address = new Address("pun", "mhr", "ind", 123456);
		Customer customer = new Customer(1001, 2589, "abi", "c", "+912569758", "abi@abcd.com", "a1", "10/2/1995");
		Transaction transaction = new Transaction( 100,250, "20:12:36:12", "withdrawal", "pune", "cash", "successful");
		System.out.print(" CustomerId: "+customer.getCustomerId()
		+"\n AdharNo: "+customer.getAdharNo()
		+"\n FirstName: "+customer.getFirstName()
		+"\n LastName: "+customer.getLastName()
		+"\n MobileNo: "+customer.getMobileNo()
		+"\n EmailId: "+customer.getEmailId()
		+"\n PanCardNo: "+customer.getPancardNo()
		+"\n DateOfBirth: "+customer.getDateOfBirth());

System.out.print("\n City: "+address.getCity()
		+"\n State: "+address.getState()
		+"\n Pincode: "+address.getPinCode()
		+"\n Country: "+address.getCountry());

System.out.print("\n AccountNo: "+account.getAccountNo()
		+"\n AccountBalance: "+account.getAccountBalance()
		+"\n AccountType: "+account.getAccountType());
		
System.out.print("\n TransactionId: "+transaction.getTransactionId()
		+"\n Amount: "+transaction.getAmount()
		+"\n TimeStamp: "+transaction.getTimeStamp()
		+"\n TransactionType: "+transaction.getTransactionType()
		+"\n TransactionLocation: "+transaction.getTransactionLocation()
		+"\n ModeofTransaction: "+transaction.getModeofTransaction()
		+"\n TransactionStatus: "+transaction.getTransactionStatus());*/
	

	}
public static Customer customersearch() {
	Customer customerList[]=new Customer[4];
	/*customerList[0]=new Customer(123, 245, "satish", "mahajan", "454478994", "satish@abcd.com", "47265", "01/12/1985", new Address("pune", "mhr", "india", 154546), new Account(12345, 4500, "savings"), new Transaction(142, 4562, "20:15:45:23", "credit", "pune", "cash", "successfull"));
	customerList[1]=new Customer(145, 1245, "ram", "lakshman", "486732534", "ram@abcd.com", "487454", "01/11/1995", new Address("hyd", "teg", "india", 45614),new Account(254133, 45786, "current"), new Transaction(1452, 4562, "12:45:45:78",	 "debit", "hyd","cheque", "successfull"));
	customerList[2]=new Customer(1245, 4567, "abhi", "ch", "478934487", "abhi@abcd.com", "85447", "01/08/1978",new Address("crl", "ap","india", 41523),new Account(14567, 7845, "savings,"),new  Transaction(2534, 78814, "01:45:78:56", "credit", "crl","cash","fail"));*/
	/*for(Customer customer:customerList) {
		if(customer!=null&&customer.getFirstName()=="satish"&&customer.getAccount().getAccountBalance()>4000)
			return customer;
}*/
	return null;

}
}
