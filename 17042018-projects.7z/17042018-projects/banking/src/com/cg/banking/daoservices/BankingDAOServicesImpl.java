package com.cg.banking.daoservices;

import com.cg.banking.beans.Customer;

public class BankingDAOServicesImpl {
	int insertCustomer(Customer customer) {
		return 0;
	}
	boolean updateAssociate(Customer customer) {
		return true;
	}

}
