package com.cg.banking.beans;

public class Account {
	private int accountNo,pinNumber;
	private float accountBalance;
	private String accountType;
	private Transaction []transactions;
	public Account() {
		super();
	}
	public Account(int accountNo, int pinNumber, float accountBalance, String accountType, Transaction[] transactions) {
		super();
		this.accountNo = accountNo;
		this.pinNumber = pinNumber;
		this.accountBalance = accountBalance;
		this.accountType = accountType;
		this.transactions = transactions;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public int getPinNumber() {
		return pinNumber;
	}
	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}
	public float getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public Transaction[] getTransactions() {
		return transactions;
	}
	public void setTransactions(Transaction[] transactions) {
		this.transactions = transactions;
	}
	
	
}
