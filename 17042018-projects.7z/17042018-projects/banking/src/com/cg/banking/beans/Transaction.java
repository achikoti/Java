package com.cg.banking.beans;

public class Transaction {
	private int transactionId; 
	private float amount;
	private String timeStamp,transactionType,transactionLocation,modeOfTransaction,transactionStatus;
	public Transaction() {
		super();
	}
	public Transaction(int transactionId, float amount, String timeStamp, String transactionType,
			String transactionLocation, String modeOfTransaction, String transactionStatus) {
		super();
		this.transactionId = transactionId;
		this.amount = amount;
		this.timeStamp = timeStamp;
		this.transactionType = transactionType;
		this.transactionLocation = transactionLocation;
		this.modeOfTransaction = modeOfTransaction;
		this.transactionStatus = transactionStatus;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionLocation() {
		return transactionLocation;
	}
	public void setTransactionLocation(String transactionLocation) {
		this.transactionLocation = transactionLocation;
	}
	public String getModeofTransaction() {
		return modeOfTransaction;
	}
	public void setModeofTransaction(String modeOfTransaction) {
		this.modeOfTransaction = modeOfTransaction;
	}
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	

}
