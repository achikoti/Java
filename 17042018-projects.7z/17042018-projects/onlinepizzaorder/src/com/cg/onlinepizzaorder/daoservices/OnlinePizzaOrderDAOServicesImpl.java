package com.cg.onlinepizzaorder.daoservices;

public class OnlinePizzaOrderDAOServicesImpl {

}
