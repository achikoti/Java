package com.cg.onlinepizzaorder.beans;

public class Bill {
	private int totNoOfItems,totCost;
	private float stateGST,centralGST,serviceTax,deliveryCharge;
	public Bill() {
		super();
	}
	public Bill(int totNoOfItems, int totCost, float stateGST, float centralGST, float serviceTax,
			float deliveryCharge) {
		super();
		this.totNoOfItems = totNoOfItems;
		this.totCost = totCost;
		this.stateGST = stateGST;
		this.centralGST = centralGST;
		this.serviceTax = serviceTax;
		this.deliveryCharge = deliveryCharge;
	}
	public int getTotNoOfItems() {
		return totNoOfItems;
	}
	public void setTotNoOfItems(int totNoOfItems) {
		this.totNoOfItems = totNoOfItems;
	}
	public int getTotCost() {
		return totCost;
	}
	public void setTotCost(int totCost) {
		this.totCost = totCost;
	}
	public float getStateGST() {
		return stateGST;
	}
	public void setStateGST(float stateGST) {
		this.stateGST = stateGST;
	}
	public float getCentralGST() {
		return centralGST;
	}
	public void setCentralGST(float centralGST) {
		this.centralGST = centralGST;
	}
	public float getServiceTax() {
		return serviceTax;
	}
	public void setServiceTax(float serviceTax) {
		this.serviceTax = serviceTax;
	}
	public float getDeliveryCharge() {
		return deliveryCharge;
	}
	public void setDeliveryCharge(float deliveryCharge) {
		this.deliveryCharge = deliveryCharge;
	}
	
}
