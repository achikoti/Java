package com.cg.onlinepizzaorder.beans;

public class Customer {
		private int customerID;
		private String name,mobileNo;
		private Delivery delivery;
		private Discount discount;
		private Address address;
		private Transaction transaction;
		private Dish dish;
		private Bill bill;
		public Customer() {
			super();
		}
		public Customer(int customerID, String name, String mobileNo, Delivery delivery, Discount discount, Address address,
				Transaction transaction, Dish dish, Bill bill) {
			super();
			this.customerID = customerID;
			this.name = name;
			this.mobileNo = mobileNo;
			this.delivery = delivery;
			this.discount = discount;
			this.address = address;
			this.transaction = transaction;
			this.dish = dish;
			this.bill = bill;
		}
		public int getCustomerID() {
			return customerID;
		}
		public void setCustomerID(int customerID) {
			this.customerID = customerID;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getMobileNo() {
			return mobileNo;
		}
		public void setMobileNo(String mobileNo) {
			this.mobileNo = mobileNo;
		}
		public Delivery getDelivery() {
			return delivery;
		}
		public void setDelivery(Delivery delivery) {
			this.delivery = delivery;
		}
		public Discount getDiscount() {
			return discount;
		}
		public void setDiscount(Discount discount) {
			this.discount = discount;
		}
		public Address getAddress() {
			return address;
		}
		public void setAddress(Address address) {
			this.address = address;
		}
		public Transaction getTransaction() {
			return transaction;
		}
		public void setTransaction(Transaction transaction) {
			this.transaction = transaction;
		}
		public Dish getDish() {
			return dish;
		}
		public void setDish(Dish dish) {
			this.dish = dish;
		}
		public Bill getBill() {
			return bill;
		}
		public void setBill(Bill bill) {
			this.bill = bill;
		}
		

	}



