package com.cg.onlinepizzaorder.beans;

public class Dish {
	private String dishName,dishavAvailability,popularityOfDish;
	private int dishRate;
	public Dish() {
		super();
	}
	public Dish(String dishName, String dishavAvailability, String popularityOfDish, int dishRate) {
		super();
		this.dishName = dishName;
		this.dishavAvailability = dishavAvailability;
		this.popularityOfDish = popularityOfDish;
		this.dishRate = dishRate;
	}
	public String getDishName() {
		return dishName;
	}
	public void setDishName(String dishName) {
		this.dishName = dishName;
	}
	public String getDishavAvailability() {
		return dishavAvailability;
	}
	public void setDishavAvailability(String dishavAvailability) {
		this.dishavAvailability = dishavAvailability;
	}
	public String getPopularityOfDish() {
		return popularityOfDish;
	}
	public void setPopularityOfDish(String popularityOfDish) {
		this.popularityOfDish = popularityOfDish;
	}
	public int getDishRate() {
		return dishRate;
	}
	public void setDishRate(int dishRate) {
		this.dishRate = dishRate;
	}
	
}
	
	
	
