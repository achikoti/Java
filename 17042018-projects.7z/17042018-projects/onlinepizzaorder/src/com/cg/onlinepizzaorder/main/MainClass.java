package com.cg.onlinepizzaorder.main;

import com.cg.onlinepizzaorder.beans.Address;
import com.cg.onlinepizzaorder.beans.Bill;
import com.cg.onlinepizzaorder.beans.Customer;
import com.cg.onlinepizzaorder.beans.Delivery;
import com.cg.onlinepizzaorder.beans.Discount;
import com.cg.onlinepizzaorder.beans.Dish;
import com.cg.onlinepizzaorder.beans.Transaction;

public class MainClass {

	public static void main(String[] args) {
		Customer customer= customerSearch();
		if(customer!=null)
			System.out.println("Details Found");
		else
			System.out.println("No Details Found");

	}
	public static Customer customerSearch() {
		Customer customerList[]=new Customer[4];
		customerList[0]=new Customer(1001, "abhi", "+919638527410",new Delivery("01/04/2018", "delivered"),new Discount("half", "02/04/2018", "halfd", 50),new Address("pune", "mhr", "india", 500010),new Transaction("cash", "successful", "01/04/2018", 1500),new Dish("Gajar Halwa", "present", "high", 1400),new Bill(10, 1400, 12, 12, 10, 100));
		customerList[1]=new Customer(1002, "satish", "+919568321425",new Delivery("02/04/2018", "failed"),new Discount("tenper", "03/04/2018", "tend", 10),new Address("hyd", "tel", "india", 5000012),new Transaction("cash", "failed", "02/04/2018", 1200),new Dish("Onion Pizza", "unavailabale", "high", 1000),new Bill(5, 1000, 12, 12, 10, 100));
		customerList[2]=new Customer(1003, "yosh", "+919631478520", new Delivery("03/04/2018", "successful"),new Discount("thirtyper", "04/04/2018", "thirtyd", 30),new Address("del", "del", "india", 500001),new Transaction("card", "successful", "03/04/2018", 1500),new Dish("Chocolate Valcano", "availabale", "high", 2000),new Bill(1, 1800, 12, 12, 10, 150));
		for(Customer customer:customerList) {
			if(customer!=null&&customer.getName()=="yosh"&&customer.getDelivery().getDateOfDelivery()=="03/04/2018"&&customer.getDiscount().getDiscountValidityDate()=="04/04/2018")
				return customer;
			
		}
		return null;
	}

}
