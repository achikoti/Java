package com.cg.mobilebilling.main;


import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostPaidAccount;

public class MainClass {

	public static void main(String[] args) {
		Customer customer=customerSearch();
		if(customer!=null)
			System.out.println("Details Found");
		else
			System.out.println("No Details Found");
		/*Address address = new Address("pun", "mhr", "ind", 123456);
		Bill bill=new Bill(12134, 12, 123, 250, 300, 150, "jan", 18, 18, 300, 200, 369, 450, 600);
		Customer customer=new Customer(1456, 36987, "abi", "c", "+91589647", "abi@abcd.com", "a1", "25/12/1995");
		Plan plan=new Plan(1256, 2589, 60, 60, 30, 25, 36, 25, 369, 85, 1, 25, "ts", "xyz");
		PostPaidAccount postpaidaccount=new PostPaidAccount("+91568796");
		System.out.println("City: "+address.getCity()
											+"\n State: "+address.getState()
											+"\n Country: "+address.getCountry()
											+"\n PinCode: "+address.getPinCode());
		System.out.println(" BillId: "+bill.getBillID()
											+"\n NoOfLocalSMS: "+bill.getNoOfLocalSMS()
											+"\n NoOfStdSMS: "+bill.getNoOfLocalSMS()
											+"\n NoOfLocalCalls: "+bill.getNoOfLocalCalls()
											+"\n NoOfStdCalls: "+bill.getNoOfStdCalls()
											+"\n  InternetDataUsageUnits: "+bill.getInternetDataUsageUnits()
											+"\n BillMonth: "+bill.getBillMonth()
											+"\n StateGST: "+bill.getStateGST()
											+"\n CentralGST: "+bill.getCentralGST()
											+"\n TotalBillAmount: "+bill.getTotalBillAmount()
											+"\n LocalSMSAmount: "+bill.getLocalCallAmount()
											+"\n StdSMSAmount: "+bill.getStdSMSAmount()
											+"\n LocalCallAmount: "+bill.getLocalCallAmount()
											+"\n InternetDataUsageUnitsAmount: "+bill.getInternetDataUsageUnitsAmount());
		System.out.print(" CustomerId: "+customer.getCustomerId()
											+"\n AdharNo: "+customer.getAdharNo()
											+"\n FirstName: "+customer.getFirstName()
											+"\n LastName: "+customer.getLastName()
											+"\n MobileNo: "+customer.getMobileNo()
											+"\n EmailId: "+customer.getEmailId()
											+"\n PanCardNo: "+customer.getPancardNo()
											+"\n DateOfBirth: "+customer.getDateOfBirth());
		
		System.out.println("\n PlanID: "+plan.getPlanID()
											+"\n MonthlyRental: "+plan.getMonthlyRental()
											+"\n FreeLocalCalls: "+plan.getFreeLocalCalls()
											+"\n FreeStdCalls: "+plan.getFreeStdCalls()
											+"\n FreeLocalSMS: "+plan.getFreeLocalSMS()
											+"\n FreeStdSMS: " +plan.getFreeStdSMS() 
											+"\n FreeInternetDataUsageUnits: "+plan.getFreeInternetDataUsageUnits()
											+"\n LocalCallRate: "+plan.getLocalCallRate()
											+"\n StdCallRate: "+plan.getStdCallRate()
											+"\n LocalSMSRate: "+plan.getLocalSMSRate() 
											+"\n StdSMSRate: "+plan.getStdSMSRate()
											+"\n InternetDataUsageRate: "+plan.getInternetDataUsageRate()
											+"\n PlanCircle: "+plan.getPlanCircle()
											+"\n PlanName: "+plan.getPlanName());
		System.out.println("\n MobileNo: "+postpaidaccount.getMobileNo());*/
	}
	public static Customer customerSearch() {
		Customer customer[]=new Customer[4]; 
		return null;
	}
}
