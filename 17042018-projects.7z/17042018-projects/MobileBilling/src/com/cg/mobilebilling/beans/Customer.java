package com.cg.mobilebilling.beans;

public class Customer {
	private int customerId,adharNo;
	private String firstName,lastName,mobileNo,emailId,pancardNo,dateOfBirth;
	private PostPaidAccount []postpaidaccounts;
	private Address localAddress,homeAddress;
	public Customer() {
		super();
	}
	public Customer(int customerId, int adharNo, String firstName, String lastName, String mobileNo, String emailId,
			String pancardNo, String dateOfBirth, PostPaidAccount[] postpaidaccounts, Address localAddress,
			Address homeAddress) {
		super();
		this.customerId = customerId;
		this.adharNo = adharNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNo = mobileNo;
		this.emailId = emailId;
		this.pancardNo = pancardNo;
		this.dateOfBirth = dateOfBirth;
		this.postpaidaccounts = postpaidaccounts;
		this.localAddress = localAddress;
		this.homeAddress = homeAddress;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(int adharNo) {
		this.adharNo = adharNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public PostPaidAccount[] getPostpaidaccounts() {
		return postpaidaccounts;
	}
	public void setPostpaidaccounts(PostPaidAccount[] postpaidaccounts) {
		this.postpaidaccounts = postpaidaccounts;
	}
	public Address getLocalAddress() {
		return localAddress;
	}
	public void setLocalAddress(Address localAddress) {
		this.localAddress = localAddress;
	}
	public Address getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(Address homeAddress) {
		this.homeAddress = homeAddress;
	}
	
}
