package com.cg.railwayreservation.beans;

public class Train {
	private String TrainName,StartingPoint,EndingPoint,StartingTime,ReachingTime;
	private int TrainNo;
	private Ticket ticket;
	public Train() {
		super();
	}
	public Train(String trainName, String startingPoint, String endingPoint, String startingTime, String reachingTime,
			int trainNo,  Ticket ticket) {
		super();
		TrainName = trainName;
		StartingPoint = startingPoint;
		EndingPoint = endingPoint;
		StartingTime = startingTime;
		ReachingTime = reachingTime;
		TrainNo = trainNo;
	
		this.ticket = ticket;
		
	}
	public String getTrainName() {
		return TrainName;
	}
	public void setTrainName(String trainName) {
		TrainName = trainName;
	}
	public String getStartingPoint() {
		return StartingPoint;
	}
	public void setStartingPoint(String startingPoint) {
		StartingPoint = startingPoint;
	}
	public String getEndingPoint() {
		return EndingPoint;
	}
	public void setEndingPoint(String endingPoint) {
		EndingPoint = endingPoint;
	}
	public String getStartingTime() {
		return StartingTime;
	}
	public void setStartingTime(String startingTime) {
		StartingTime = startingTime;
	}
	public String getReachingTime() {
		return ReachingTime;
	}
	public void setReachingTime(String reachingTime) {
		ReachingTime = reachingTime;
	}
	public int getTrainNo() {
		return TrainNo;
	}
	public void setTrainNo(int trainNo) {
		TrainNo = trainNo;
	}
	public Ticket getTicket() {
		return ticket;
	}
	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}

	
	
	
}
