package com.cg.railwayreservation.beans;

public class Passenger {
	private String firstName,lastName,mobileNo,gender;
	private int age,adult,child,adharNo;
	private JourneyDetails journeydetails[];
	public Passenger() {
		super();
		}
	public Passenger(String firstName, String lastName, String mobileNo, String gender, int age, int adult, int child,
			int adharNo, JourneyDetails[] journeydetails) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNo = mobileNo;
		this.gender = gender;
		this.age = age;
		this.adult = adult;
		this.child = child;
		this.adharNo = adharNo;
		this.journeydetails = journeydetails;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getAdult() {
		return adult;
	}
	public void setAdult(int adult) {
		this.adult = adult;
	}
	public int getChild() {
		return child;
	}
	public void setChild(int child) {
		this.child = child;
	}
	public int getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(int adharNo) {
		this.adharNo = adharNo;
	}
	public JourneyDetails[] getJourneydetails() {
		return journeydetails;
	}
	public void setJourneydetails(JourneyDetails[] journeydetails) {
		this.journeydetails = journeydetails;
	}
	
}