package com.cg.railwayreservation.beans;

public class JourneyDetails {
	private String fromPlace,toPlace,dateOfJourney;
	private Train train[];
	public JourneyDetails() {
		super();
	}
	public JourneyDetails(String fromPlace, String toPlace, String dateOfJourney, Train[] train) {
		super();
		this.fromPlace = fromPlace;
		this.toPlace = toPlace;
		this.dateOfJourney = dateOfJourney;
		this.train = train;
	}
	public String getFromPlace() {
		return fromPlace;
	}
	public void setFromPlace(String fromPlace) {
		this.fromPlace = fromPlace;
	}
	public String getToPlace() {
		return toPlace;
	}
	public void setToPlace(String toPlace) {
		this.toPlace = toPlace;
	}
	public String getDateOfJourney() {
		return dateOfJourney;
	}
	public void setDateOfJourney(String dateOfJourney) {
		this.dateOfJourney = dateOfJourney;
	}
	public Train[] getTrain() {
		return train;
	}
	public void setTrain(Train[] train) {
		this.train = train;
	}
	
}