package com.cg.railwayreservation.beans;

public class NoOfPassengers {
	private int ticketCost,noOfSeatsOccupied;

	public NoOfPassengers() {
		super();
	}

	public NoOfPassengers(int ticketCost, int noOfSeatsOccupied) {
		super();
		this.ticketCost = ticketCost;
		this.noOfSeatsOccupied = noOfSeatsOccupied;
	}

	public int getTicketCost() {
		return ticketCost;
	}

	public void setTicketCost(int ticketCost) {
		this.ticketCost = ticketCost;
	}

	public int getNoOfSeatsOccupied() {
		return noOfSeatsOccupied;
	}

	public void setNoOfSeatsOccupied(int noOfSeatsOccupied) {
		this.noOfSeatsOccupied = noOfSeatsOccupied;
	}
	

}
