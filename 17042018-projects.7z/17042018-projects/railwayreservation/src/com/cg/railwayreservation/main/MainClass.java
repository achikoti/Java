package com.cg.railwayreservation.main;

import com.cg.railwayreservation.beans.Cancellation;
import com.cg.railwayreservation.beans.Food;
import com.cg.railwayreservation.beans.JourneyDetails;
import com.cg.railwayreservation.beans.NoOfPassengers;
import com.cg.railwayreservation.beans.Passenger;
import com.cg.railwayreservation.beans.Train;
import com.cg.railwayreservation.beans.Transaction;

public class MainClass {

	public static void main(String[] args) {
		/*Passenger journeydetails=journeydetailsSearch();
		if(journeydetails!=null)
			System.out.println("Details Found");
		else
			System.out.println("No Details Found");*/

	}
	/*public static JourneyDetails journeydetailsSearch() {
		JourneyDetails journeydetailsList[]=new JourneyDetails[4];
		journeydetailsList[0]= new JourneyDetails(1001, "hyd", "pun", "21:00:00:00", "firstclass","01/04/2018","02/04/2018", new Passenger("satish", "+919876543210", "male", 40, 1, 0,2589),new NoOfPassengers(2500, 1),new Train("pune express", "secunderabad station", "pune station", "21:00:00:00", "06:00:00:00", 12589),new Food("food ordered", "non-veg"),new Transaction("internet banking", "successful", "30/03/2018", 2500),new Cancellation(250, 30,"31/03/2018"));
		journeydetailsList[1]= new JourneyDetails(2158, "pun", "chennai", "22:00:00:00", "secondclass","05/04/2018","06/04/2018", new Passenger("abhi", "+91987656810", "male", 22, 1, 0,2566),new NoOfPassengers(2500, 1),new Train("chennai express", "pune station", "chennai station", "22:00:00:00", "07:00:00:00", 12566),new Food("food ordered", "veg"),new Transaction("cash", "successful", "29/03/2018", 2500),new Cancellation(300, 20,"01/04/2018"));
		journeydetailsList[2]= new JourneyDetails(1002, "del", "pun", "21:00:00:00", "firstclass","01/04/2018","03/04/2018", new Passenger("yosh", "+918876543210", "female", 22, 1, 0,2689),new NoOfPassengers(5000, 1),new Train("rajdhani express", "delhi station", "pune station", "18:00:00:00", "02:00:00:00", 12589),new Food("food ordered", "non-veg"),new Transaction("internet banking", "successful", "30/03/2018", 2500),new Cancellation(500, 10,"31/03/2018"));
		for(JourneyDetails journeydetails:journeydetailsList) {
			if(journeydetails!=null&&journeydetails.getTicketID()==1001&&journeydetails.getFood().getTypeOfFood()=="non-veg")
				return journeydetails;
		}
		
		return null;
	}*/

}
