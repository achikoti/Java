package com.cg.onlinecabbooking.main;

import com.cg.onlinecabbooking.beans.CabDetails;
import com.cg.onlinecabbooking.beans.Customer;
import com.cg.onlinecabbooking.beans.Transaction;
import com.cg.onlinecabbooking.beans.TravellingDetails;

public class MainClass {

	public static void main(String[] args) {
		Customer customer= customerSearch();
		if(customer!=null)
			System.out.println("Details Found");
		else
			System.out.println("No Details Found");

	}
	public static Customer customerSearch() {
		Customer customerList[]=new Customer[4];
		customerList[0]= new Customer("satish", "mahajan", "+919875643210", "satish@abcd.com", 1234, new TravellingDetails("talwade", "hinjewadi", "25/03/2018", "25/03/2018", "SUV", "25/03/2018", "25/03/2018", 5, 700),new Transaction("cash", "successful", "25/03/2018", 700),new CabDetails("MH 01 PX 1234", "xyz", 1478, 11111));
		customerList[1]= new Customer("abhi", "c", "+919875643211", "abhi@abcd.com", 1235, new TravellingDetails("talwade", "pune", "26/03/2018", "26/03/2018", "Innova", "26/03/2018", "26/03/2018", 3, 800),new Transaction("cash", "successful", "26/03/2018", 800),new CabDetails("MH 01 PX 1235", "wxyz", 1479, 11112));
		customerList[2]= new Customer("yosh", "a", "+919875643212", "yosh@abcd.com", 1236, new TravellingDetails("talwade", "mumbai", "27/03/2018", "27/03/2018", "jeep", "27/03/2018", "27/03/2018", 4, 900),new Transaction("internet banking", "successful", "27/03/2018", 900),new CabDetails("MH 01 PX 1236", "vxyz", 1479, 11113));
		for(Customer customer:customerList) {
			if(customer!=null&&customer.getFirstName()=="yosh"&&customer.getCabdetails().getoTP()==11113)
				return customer;
			
		}
		
		
		return null;
	}
}
