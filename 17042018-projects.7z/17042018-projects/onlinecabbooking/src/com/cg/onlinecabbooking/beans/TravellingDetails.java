package com.cg.onlinecabbooking.beans;

public class TravellingDetails {
	private String from,to,dateOfBooking,dateOfTravel,typeOfCab,fromDate,toDate;
	private int noOfPassengers,travelCost;
	public TravellingDetails() {
		super();
	}
	public TravellingDetails(String from, String to, String dateOfBooking, String dateOfTravel, String typeOfCab,
			String fromDate, String toDate, int noOfPassengers, int travelCost) {
		super();
		this.from = from;
		this.to = to;
		this.dateOfBooking = dateOfBooking;
		this.dateOfTravel = dateOfTravel;
		this.typeOfCab = typeOfCab;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.noOfPassengers = noOfPassengers;
		this.travelCost = travelCost;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getDateOfBooking() {
		return dateOfBooking;
	}
	public void setDateOfBooking(String dateOfBooking) {
		this.dateOfBooking = dateOfBooking;
	}
	public String getDateOfTravel() {
		return dateOfTravel;
	}
	public void setDateOfTravel(String dateOfTravel) {
		this.dateOfTravel = dateOfTravel;
	}
	public String getTypeOfCab() {
		return typeOfCab;
	}
	public void setTypeOfCab(String typeOfCab) {
		this.typeOfCab = typeOfCab;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public int getNoOfPassengers() {
		return noOfPassengers;
	}
	public void setNoOfPassengers(int noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}
	public int getTravelCost() {
		return travelCost;
	}
	public void setTravelCost(int travelCost) {
		this.travelCost = travelCost;
	}
	

}
