package com.cg.onlinecabbooking.beans;

public class Customer {
	private String firstName,lastName,mobileNo,emailID;
	private int customerID;
	private TravellingDetails travellingdetails;
	private Transaction transaction;
	private CabDetails cabdetails;
	public Customer() {
		super();
	}
	public Customer(String firstName, String lastName, String mobileNo, String emailID, int customerID,
			TravellingDetails travellingdetails, Transaction transaction, CabDetails cabdetails) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNo = mobileNo;
		this.emailID = emailID;
		this.customerID = customerID;
		this.travellingdetails = travellingdetails;
		this.transaction = transaction;
		this.cabdetails = cabdetails;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public TravellingDetails getTravellingdetails() {
		return travellingdetails;
	}
	public void setTravellingdetails(TravellingDetails travellingdetails) {
		this.travellingdetails = travellingdetails;
	}
	public Transaction getTransaction() {
		return transaction;
	}
	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}
	public CabDetails getCabdetails() {
		return cabdetails;
	}
	public void setCabdetails(CabDetails cabdetails) {
		this.cabdetails = cabdetails;
	}
	
	

}
