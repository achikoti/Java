package com.cg.onlinecabbooking.beans;

public class CabDetails {
	private String vehicleNo,driverName;
	private int bookingID,oTP;
	public CabDetails() {
		super();
	}
	public CabDetails(String vehicleNo, String driverName, int bookingID, int oTP) {
		super();
		this.vehicleNo = vehicleNo;
		this.driverName = driverName;
		this.bookingID = bookingID;
		this.oTP = oTP;
	}
	public String getVehicleNo() {
		return vehicleNo;
	}
	public void setVehicleNo(String vehicleNo) {
		this.vehicleNo = vehicleNo;
	}
	public String getDriverName() {
		return driverName;
	}
	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}
	public int getBookingID() {
		return bookingID;
	}
	public void setBookingID(int bookingID) {
		this.bookingID = bookingID;
	}
	public int getoTP() {
		return oTP;
	}
	public void setoTP(int oTP) {
		this.oTP = oTP;
	}
	
	
}
