package com.cg.librarymanagement.beans;


public class User {
	private int userID,adharNo;
	private String firstName,lastName,mobileNo,emailID;
	private Address address;
	private Book book;
	private Issue issue;
	private Penality penality;
	public User() {
		super();
	}
	public User(int userID, int adharNo, String firstName, String lastName, String mobileNo, String emailID,
			Address address, Book book, Issue issue, Penality penality) {
		super();
		this.userID = userID;
		this.adharNo = adharNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNo = mobileNo;
		this.emailID = emailID;
		this.address = address;
		this.book = book;
		this.issue = issue;
		this.penality = penality;
	}
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public int getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(int adharNo) {
		this.adharNo = adharNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	public Issue getIssue() {
		return issue;
	}
	public void setIssue(Issue issue) {
		this.issue = issue;
	}
	public Penality getPenality() {
		return penality;
	}
	public void setPenality(Penality penality) {
		this.penality = penality;
	}
	

}
