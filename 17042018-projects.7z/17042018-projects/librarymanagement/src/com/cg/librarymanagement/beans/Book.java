package com.cg.librarymanagement.beans;

public class Book {
	private String typeOfBook,bookName,bookAvailability;
	private int bookID,totNoOfBooks,NoOfBooksAva,NoOfBooksIssued;
	public Book() {
		super();
	}
	public Book(String typeOfBook, String bookName, String bookAvailability, int bookID, int totNoOfBooks,
			int noOfBooksAva, int noOfBooksIssued) {
		super();
		this.typeOfBook = typeOfBook;
		this.bookName = bookName;
		this.bookAvailability = bookAvailability;
		this.bookID = bookID;
		this.totNoOfBooks = totNoOfBooks;
		NoOfBooksAva = noOfBooksAva;
		NoOfBooksIssued = noOfBooksIssued;
	}
	public String getTypeOfBook() {
		return typeOfBook;
	}
	public void setTypeOfBook(String typeOfBook) {
		this.typeOfBook = typeOfBook;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getBookAvailability() {
		return bookAvailability;
	}
	public void setBookAvailability(String bookAvailability) {
		this.bookAvailability = bookAvailability;
	}
	public int getBookID() {
		return bookID;
	}
	public void setBookID(int bookID) {
		this.bookID = bookID;
	}
	public int getTotNoOfBooks() {
		return totNoOfBooks;
	}
	public void setTotNoOfBooks(int totNoOfBooks) {
		this.totNoOfBooks = totNoOfBooks;
	}
	public int getNoOfBooksAva() {
		return NoOfBooksAva;
	}
	public void setNoOfBooksAva(int noOfBooksAva) {
		NoOfBooksAva = noOfBooksAva;
	}
	public int getNoOfBooksIssued() {
		return NoOfBooksIssued;
	}
	public void setNoOfBooksIssued(int noOfBooksIssued) {
		NoOfBooksIssued = noOfBooksIssued;
	}
	
	
}
