package com.cg.librarymanagement.beans;

public class Issue {
	private String issueDate,issueFromDate,issueToDate,issueCheck,bookIssueStatus;
	private int issuedTo,issueDuration,issuedBookID;
	public Issue() {
		super();
	}
	public Issue(String issueDate, String issueFromDate, String issueToDate, String issueCheck, String bookIssueStatus,
			int issuedTo, int issueDuration, int issuedBookID) {
		super();
		this.issueDate = issueDate;
		this.issueFromDate = issueFromDate;
		this.issueToDate = issueToDate;
		this.issueCheck = issueCheck;
		this.bookIssueStatus = bookIssueStatus;
		this.issuedTo = issuedTo;
		this.issueDuration = issueDuration;
		this.issuedBookID = issuedBookID;
	}
	public String getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}
	public String getIssueFromDate() {
		return issueFromDate;
	}
	public void setIssueFromDate(String issueFromDate) {
		this.issueFromDate = issueFromDate;
	}
	public String getIssueToDate() {
		return issueToDate;
	}
	public void setIssueToDate(String issueToDate) {
		this.issueToDate = issueToDate;
	}
	public String getIssueCheck() {
		return issueCheck;
	}
	public void setIssueCheck(String issueCheck) {
		this.issueCheck = issueCheck;
	}
	public String getBookIssueStatus() {
		return bookIssueStatus;
	}
	public void setBookIssueStatus(String bookIssueStatus) {
		this.bookIssueStatus = bookIssueStatus;
	}
	public int getIssuedTo() {
		return issuedTo;
	}
	public void setIssuedTo(int issuedTo) {
		this.issuedTo = issuedTo;
	}
	public int getIssueDuration() {
		return issueDuration;
	}
	public void setIssueDuration(int issueDuration) {
		this.issueDuration = issueDuration;
	}
	public int getIssuedBookID() {
		return issuedBookID;
	}
	public void setIssuedBookID(int issuedBookID) {
		this.issuedBookID = issuedBookID;
	}
	

}
