package com.cg.librarymanagement.main;
import com.cg.librarymanagement.beans.Address;
import com.cg.librarymanagement.beans.Book;
import com.cg.librarymanagement.beans.Issue;
import com.cg.librarymanagement.beans.Penality;
import com.cg.librarymanagement.beans.User;

public class MainClass {

	public static void main(String[] args) {
		User user=userSearch();
		if(user!=null)
			System.out.println("Details Found");
		else
			System.out.println("No Details Found");

	}
	public static User userSearch() {
		User userList[]=new User[4];
		userList[0]= new User(101, 12345, "abhi", "c", "+919638527410", "abhi@abcd.com", new Address("pune", "mhr", "india", 501000),new Book("sci-fi", "xyz", "available", 1000, 10, 6, 4),new Issue("25/03/2018","25/03/2018","28/03/2018","isuued","not issued",100,3,100), new Penality(0, 10, "no need to pay"));
		userList[0]= new User(121, 12345, "yosh", "c", "+919638527411", "yosh@abcd.com", new Address("pune", "mhr", "india", 501000),new Book("sci-fi", "wsr", "available", 1000, 10, 6, 4),new Issue("25/03/2018","25/03/2018","28/03/2018","isuued","not issued",101,3,100), new Penality(0, 10, "no need to pay"));
		for(User users:userList) {
			if(users!=null&&users.getBook().getBookID()==1000)
				return users;
		}
		return null;
	}

}
