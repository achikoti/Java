package com.cg.housingdotcom.beans;

public class Seller {
	private String nameOfSeller,mobileNo;

	public Seller() {
		super();
	}

	public Seller(String nameOfSeller, String mobileNo) {
		super();
		this.nameOfSeller = nameOfSeller;
		this.mobileNo = mobileNo;
	}

	public String getNameOfSeller() {
		return nameOfSeller;
	}

	public void setNameOfSeller(String nameOfSeller) {
		this.nameOfSeller = nameOfSeller;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
}
