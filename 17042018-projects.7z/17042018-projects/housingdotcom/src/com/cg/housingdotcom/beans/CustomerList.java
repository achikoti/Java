package com.cg.housingdotcom.beans;

public class CustomerList {
	private int noOfCustomersReached;
	private String customerFeedback,nameOfCustomer;
	public CustomerList() {
		super();
	}
	public CustomerList(int noOfCustomersReached, String customerFeedback, String nameOfCustomer) {
		super();
		this.noOfCustomersReached = noOfCustomersReached;
		this.customerFeedback = customerFeedback;
		this.nameOfCustomer = nameOfCustomer;
	}
	public int getNoOfCustomersReached() {
		return noOfCustomersReached;
	}
	public void setNoOfCustomersReached(int noOfCustomersReached) {
		this.noOfCustomersReached = noOfCustomersReached;
	}
	public String getCustomerFeedback() {
		return customerFeedback;
	}
	public void setCustomerFeedback(String customerFeedback) {
		this.customerFeedback = customerFeedback;
	}
	public String getNameOfCustomer() {
		return nameOfCustomer;
	}
	public void setNameOfCustomer(String nameOfCustomer) {
		this.nameOfCustomer = nameOfCustomer;
	}
	
	
}
