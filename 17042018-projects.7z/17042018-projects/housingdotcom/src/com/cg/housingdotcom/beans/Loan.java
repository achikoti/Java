package com.cg.housingdotcom.beans;

public class Loan {
	private int loanAvailability,principleAmountFirstPaid,interestCharge,duration;

	public Loan() {
		super();
	}

	public Loan(int loanAvailability, int principleAmountFirstPaid, int interestCharge, int duration) {
		super();
		this.loanAvailability = loanAvailability;
		this.principleAmountFirstPaid = principleAmountFirstPaid;
		this.interestCharge = interestCharge;
		this.duration = duration;
	}

	public int getLoanAvailability() {
		return loanAvailability;
	}

	public void setLoanAvailability(int loanAvailability) {
		this.loanAvailability = loanAvailability;
	}

	public int getPrincipleAmountFirstPaid() {
		return principleAmountFirstPaid;
	}

	public void setPrincipleAmountFirstPaid(int principleAmountFirstPaid) {
		this.principleAmountFirstPaid = principleAmountFirstPaid;
	}

	public int getInterestCharge() {
		return interestCharge;
	}

	public void setInterestCharge(int interestCharge) {
		this.interestCharge = interestCharge;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}
	
}
