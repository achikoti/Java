package com.cg.housingdotcom.beans;

public class Flat {
	private String flatAvailability,typeOfFlat,typeOfSellingSR,flatBuySale;
	private int flatNo,measurement,flatCost;
	
	public Flat() {
		super();
	}

	public Flat(String flatAvailability, String typeOfFlat, String typeOfSellingSR, String flatBuySale, int flatNo,
			int measurement, int flatCost) {
		super();
		this.flatAvailability = flatAvailability;
		this.typeOfFlat = typeOfFlat;
		this.typeOfSellingSR = typeOfSellingSR;
		this.flatBuySale = flatBuySale;
		this.flatNo = flatNo;
		this.measurement = measurement;
		this.flatCost = flatCost;
	}

	public String getFlatAvailability() {
		return flatAvailability;
	}

	public void setFlatAvailability(String flatAvailability) {
		this.flatAvailability = flatAvailability;
	}

	public String getTypeOfFlat() {
		return typeOfFlat;
	}

	public void setTypeOfFlat(String typeOfFlat) {
		this.typeOfFlat = typeOfFlat;
	}

	public String getTypeOfSellingSR() {
		return typeOfSellingSR;
	}

	public void setTypeOfSellingSR(String typeOfSellingSR) {
		this.typeOfSellingSR = typeOfSellingSR;
	}

	public String getFlatBuySale() {
		return flatBuySale;
	}

	public void setFlatBuySale(String flatBuySale) {
		this.flatBuySale = flatBuySale;
	}

	public int getFlatNo() {
		return flatNo;
	}

	public void setFlatNo(int flatNo) {
		this.flatNo = flatNo;
	}

	public int getMeasurement() {
		return measurement;
	}

	public void setMeasurement(int measurement) {
		this.measurement = measurement;
	}

	public int getFlatCost() {
		return flatCost;
	}

	public void setFlatCost(int flatCost) {
		this.flatCost = flatCost;
	}
			
}
