package com.cg.housingdotcom.daoservices;

public class HousingDotComDAOServicesImpl {

}
