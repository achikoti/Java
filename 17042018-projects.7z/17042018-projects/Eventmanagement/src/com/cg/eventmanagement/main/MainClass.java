package com.cg.eventmanagement.main;
import com.cg.eventmanagement.beans.Bill;
import com.cg.eventmanagement.beans.Catering;
import com.cg.eventmanagement.beans.Customer;
import com.cg.eventmanagement.beans.Discount;
import com.cg.eventmanagement.beans.Event;
import com.cg.eventmanagement.beans.EventAddress;
import com.cg.eventmanagement.beans.Menu;
import com.cg.eventmanagement.beans.Transaction;

public class MainClass {

	public static void main(String[] args) {
		Event event =eventSearch();
		if(event!=null)
			System.out.println("Details Found");
		else
			System.out.println("No Details Found");
		

	}
	public static Event eventSearch() {
		Event eventList[]=new Event[4];
		eventList[0]=new Event("House Warming","25/03/2018","26/03/2018",1001,50000,1,100,new Customer("abhi", "c", "+919638527410", 1234),new Catering("No", "----", 0),new EventAddress("pune", "mhr", "india", 502110),new Menu("----", "----", 0),new Discount("half", "31/12/2018", "halfd",25000),new Bill(25000, 12, 12, 10),new Transaction("cash", "successful", "27/03/2018", 25000));
		eventList[1]=new Event("House Warming","25/03/2018","26/03/2018",1001,50000,1,100,new Customer("satish", "mahajan", "+919638527411", 1235),new Catering("No", "----", 0),new EventAddress("pune", "mhr", "india", 502110),new Menu("----", "----", 0),new Discount("half", "31/12/2018", "halfd",25000),new Bill(25000, 12, 12, 10),new Transaction("cash", "successful", "27/03/2018", 25000));
		for(Event events:eventList) {
			if(events!=null&&events.getCustomer().getFirstName()=="satish")
				return events;
		}
		return null;
	}

}
