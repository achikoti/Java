package com.cg.eventmanagement.beans;

public class Menu {
	private String nameOfItem,itemAvailability;
	private int itemCost;
	public Menu() {
		super();
	}
	public Menu(String nameOfItem, String itemAvailability, int itemCost) {
		super();
		this.nameOfItem = nameOfItem;
		this.itemAvailability = itemAvailability;
		this.itemCost = itemCost;
	}
	public String getNameOfItem() {
		return nameOfItem;
	}
	public void setNameOfItem(String nameOfItem) {
		this.nameOfItem = nameOfItem;
	}
	public String getItemAvailability() {
		return itemAvailability;
	}
	public void setItemAvailability(String itemAvailability) {
		this.itemAvailability = itemAvailability;
	}
	public int getItemCost() {
		return itemCost;
	}
	public void setItemCost(int itemCost) {
		this.itemCost = itemCost;
	}
	
}
