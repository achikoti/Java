package com.cg.eventmanagement.beans;

public class Catering {
	private String cateringStatus,cateringType;
	private int cateringCost;
	public Catering() {
		super();
	}
	public Catering(String cateringStatus, String cateringType, int cateringCost) {
		super();
		this.cateringStatus = cateringStatus;
		this.cateringType = cateringType;
		this.cateringCost = cateringCost;
	}
	public String getCateringStatus() {
		return cateringStatus;
	}
	public void setCateringStatus(String cateringStatus) {
		this.cateringStatus = cateringStatus;
	}
	public String getCateringType() {
		return cateringType;
	}
	public void setCateringType(String cateringType) {
		this.cateringType = cateringType;
	}
	public int getCateringCost() {
		return cateringCost;
	}
	public void setCateringCost(int cateringCost) {
		this.cateringCost = cateringCost;
	}
	
}
