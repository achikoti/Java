package com.cg.eventmanagement.beans;

public class Event {
	private String typeOfEvent,eventFromDate,eventToDate;
	private int eventID,eventCost,noOfDays,noOfAttendies;
	private Customer customer;
	private Catering catering;
	private EventAddress eventaddress;
	private Menu menu;
	private Discount discount;
	private Bill bill;
	private Transaction transaction;
	public Event() {
		super();
	}
	public Event(String typeOfEvent, String eventFromDate, String eventToDate, int eventID, int eventCost, int noOfDays,
			int noOfAttendies, Customer customer, Catering catering, EventAddress eventaddress, Menu menu,
			Discount discount, Bill bill, Transaction transaction) {
		super();
		this.typeOfEvent = typeOfEvent;
		this.eventFromDate = eventFromDate;
		this.eventToDate = eventToDate;
		this.eventID = eventID;
		this.eventCost = eventCost;
		this.noOfDays = noOfDays;
		this.noOfAttendies = noOfAttendies;
		this.customer = customer;
		this.catering = catering;
		this.eventaddress = eventaddress;
		this.menu = menu;
		this.discount = discount;
		this.bill = bill;
		this.transaction = transaction;
	}
	public String getTypeOfEvent() {
		return typeOfEvent;
	}
	public void setTypeOfEvent(String typeOfEvent) {
		this.typeOfEvent = typeOfEvent;
	}
	public String getEventFromDate() {
		return eventFromDate;
	}
	public void setEventFromDate(String eventFromDate) {
		this.eventFromDate = eventFromDate;
	}
	public String getEventToDate() {
		return eventToDate;
	}
	public void setEventToDate(String eventToDate) {
		this.eventToDate = eventToDate;
	}
	public int getEventID() {
		return eventID;
	}
	public void setEventID(int eventID) {
		this.eventID = eventID;
	}
	public int getEventCost() {
		return eventCost;
	}
	public void setEventCost(int eventCost) {
		this.eventCost = eventCost;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	public int getNoOfAttendies() {
		return noOfAttendies;
	}
	public void setNoOfAttendies(int noOfAttendies) {
		this.noOfAttendies = noOfAttendies;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Catering getCatering() {
		return catering;
	}
	public void setCatering(Catering catering) {
		this.catering = catering;
	}
	public EventAddress getEventaddress() {
		return eventaddress;
	}
	public void setEventaddress(EventAddress eventaddress) {
		this.eventaddress = eventaddress;
	}
	public Menu getMenu() {
		return menu;
	}
	public void setMenu(Menu menu) {
		this.menu = menu;
	}
	public Discount getDiscount() {
		return discount;
	}
	public void setDiscount(Discount discount) {
		this.discount = discount;
	}
	public Bill getBill() {
		return bill;
	}
	public void setBill(Bill bill) {
		this.bill = bill;
	}
	public Transaction getTransaction() {
		return transaction;
	}
	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}
	
}
