package com.cg.eventmanagement.beans;

public class Discount {
	private String  previousCustomer,typeOfDiscount,discountValidityDate,discountCode;
	private float discountRate;
	public Discount() {
		super();
	}
	public Discount(String typeOfDiscount, String discountValidityDate, String discountCode, float discountRate) {
		super();
		this.typeOfDiscount = typeOfDiscount;
		this.discountValidityDate = discountValidityDate;
		this.discountCode = discountCode;
		this.discountRate = discountRate;
	}
	public String getTypeOfDiscount() {
		return typeOfDiscount;
	}
	public void setTypeOfDiscount(String typeOfDiscount) {
		this.typeOfDiscount = typeOfDiscount;
	}
	public String getDiscountValidityDate() {
		return discountValidityDate;
	}
	public void setDiscountValidityDate(String discountValidityDate) {
		this.discountValidityDate = discountValidityDate;
	}
	public String getDiscountCode() {
		return discountCode;
	}
	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}
	public float getDiscountRate() {
		return discountRate;
	}
	public void setDiscountRate(float discountRate) {
		this.discountRate = discountRate;
	}

}
