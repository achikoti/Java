package com.cg.eventmanagement.beans;

public class Bill {
	private float totCost,stateGST,centralGST,serviceTax;
	public Bill() {
		super();
	}
	public Bill(float totCost, float stateGST, float centralGST, float serviceTax) {
		super();
		this.totCost = totCost;
		this.stateGST = stateGST;
		this.centralGST = centralGST;
		this.serviceTax = serviceTax;
	}
	public float getTotCost() {
		return totCost;
	}
	public void setTotCost(float totCost) {
		this.totCost = totCost;
	}
	public float getStateGST() {
		return stateGST;
	}
	public void setStateGST(float stateGST) {
		this.stateGST = stateGST;
	}
	public float getCentralGST() {
		return centralGST;
	}
	public void setCentralGST(float centralGST) {
		this.centralGST = centralGST;
	}
	public float getServiceTax() {
		return serviceTax;
	}
	public void setServiceTax(float serviceTax) {
		this.serviceTax = serviceTax;
	}
	

}
