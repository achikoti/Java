package com.cg.onlineexam.beans;

public class Examinee {

}
