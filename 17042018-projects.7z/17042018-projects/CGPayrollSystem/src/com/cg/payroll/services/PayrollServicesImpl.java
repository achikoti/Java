package com.cg.payroll.services;
import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
public class PayrollServicesImpl {
	
	private PayrollDAOServicesImpl daoServices;
	
	public PayrollServicesImpl() {
		daoServices=new PayrollDAOServicesImpl();
	}
	
	public int acceptAssociateDetails(String firstName, String lastName,
			 String emailId,String department, String designation, String pancard,
			 int yearlyInvestmentUnder80C,float basicSalary,float epf,float companyPf,int accountNumber
			 ,String bankName, String ifscCode) {
		return 0;
	}
	public int calculateNetSalary(int associateID) {
		return 0;
	}
	public Associate getAssociateDetails(int assoociateID) {
		return null;
	}
	public Associate[] getAllAssociatesDetails() {
		return null;
	}

}
