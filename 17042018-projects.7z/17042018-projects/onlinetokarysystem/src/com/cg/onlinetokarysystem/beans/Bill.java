package com.cg.onlinetokarysystem.beans;

public class Bill {
	private int totNoOfItems,deliveryCharge;
	private float totCost,stateGST,centralGST,serviceTax;
	public Bill() {
		super();
	}
	public Bill(int totNoOfItems, int deliveryCharge, float totCost, float stateGST, float centralGST,
			float serviceTax) {
		super();
		this.totNoOfItems = totNoOfItems;
		this.deliveryCharge = deliveryCharge;
		this.totCost = totCost;
		this.stateGST = stateGST;
		this.centralGST = centralGST;
		this.serviceTax = serviceTax;
	}
	public int getTotNoOfItems() {
		return totNoOfItems;
	}
	public void setTotNoOfItems(int totNoOfItems) {
		this.totNoOfItems = totNoOfItems;
	}
	public int getDeliveryCharge() {
		return deliveryCharge;
	}
	public void setDeliveryCharge(int deliveryCharge) {
		this.deliveryCharge = deliveryCharge;
	}
	public float getTotCost() {
		return totCost;
	}
	public void setTotCost(float totCost) {
		this.totCost = totCost;
	}
	public float getStateGST() {
		return stateGST;
	}
	public void setStateGST(float stateGST) {
		this.stateGST = stateGST;
	}
	public float getCentralGST() {
		return centralGST;
	}
	public void setCentralGST(float centralGST) {
		this.centralGST = centralGST;
	}
	public float getServiceTax() {
		return serviceTax;
	}
	public void setServiceTax(float serviceTax) {
		this.serviceTax = serviceTax;
	}
	
}
