package com.cg.onlinetokarysystem.beans;

public class Items {
	private String itemName,itemAvailability;
	private int noOfItems,itemCost;
	public Items() {
		super();
	}
	public Items(String itemName, String itemAvailability, int noOfItems, int itemCost) {
		super();
		this.itemName = itemName;
		this.itemAvailability = itemAvailability;
		this.noOfItems = noOfItems;
		this.itemCost = itemCost;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getItemAvailability() {
		return itemAvailability;
	}
	public void setItemAvailability(String itemAvailability) {
		this.itemAvailability = itemAvailability;
	}
	public int getNoOfItems() {
		return noOfItems;
	}
	public void setNoOfItems(int noOfItems) {
		this.noOfItems = noOfItems;
	}
	public int getItemCost() {
		return itemCost;
	}
	public void setItemCost(int itemCost) {
		this.itemCost = itemCost;
	}
	
}
