package com.cg.onlinetokarysystem.beans;

public class Customer {
	private String firstName,lastName,mobileNo;
	private int customerID;
	private DeliveryAddress deliveryaddress;
	private Items items;
	private Bill bill;
	private Delivery delivery;
	private Discount discount;
	private Transaction transaction;
	public Customer() {
		super();
	}
	public Customer(String firstName, String lastName, String mobileNo, int customerID, DeliveryAddress deliveryaddress,
			Items items, Bill bill, Delivery delivery, Discount discount, Transaction transaction) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNo = mobileNo;
		this.customerID = customerID;
		this.deliveryaddress = deliveryaddress;
		this.items = items;
		this.bill = bill;
		this.delivery = delivery;
		this.discount = discount;
		this.transaction = transaction;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public DeliveryAddress getDeliveryaddress() {
		return deliveryaddress;
	}
	public void setDeliveryaddress(DeliveryAddress deliveryaddress) {
		this.deliveryaddress = deliveryaddress;
	}
	public Items getItems() {
		return items;
	}
	public void setItems(Items items) {
		this.items = items;
	}
	public Bill getBill() {
		return bill;
	}
	public void setBill(Bill bill) {
		this.bill = bill;
	}
	public Delivery getDelivery() {
		return delivery;
	}
	public void setDelivery(Delivery delivery) {
		this.delivery = delivery;
	}
	public Discount getDiscount() {
		return discount;
	}
	public void setDiscount(Discount discount) {
		this.discount = discount;
	}
	public Transaction getTransaction() {
		return transaction;
	}
	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}

}
