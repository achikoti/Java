package com.cg.onlinetokarysystem.beans;

public class Delivery {
	private String dateOfDelivery,deliveryStatus;

	public Delivery() {
		super();
	}

	public Delivery(String dateOfDelivery, String deliveryStatus) {
		super();
		this.dateOfDelivery = dateOfDelivery;
		this.deliveryStatus = deliveryStatus;
	}

	public String getDateOfDelivery() {
		return dateOfDelivery;
	}

	public void setDateOfDelivery(String dateOfDelivery) {
		this.dateOfDelivery = dateOfDelivery;
	}

	public String getDeliveryStatus() {
		return deliveryStatus;
	}

	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	
	

}
