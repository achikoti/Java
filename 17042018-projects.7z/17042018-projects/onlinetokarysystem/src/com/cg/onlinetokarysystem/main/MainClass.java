package com.cg.onlinetokarysystem.main;

import com.cg.onlinetokarysystem.beans.Bill;
import com.cg.onlinetokarysystem.beans.Customer;
import com.cg.onlinetokarysystem.beans.Delivery;
import com.cg.onlinetokarysystem.beans.DeliveryAddress;
import com.cg.onlinetokarysystem.beans.Discount;
import com.cg.onlinetokarysystem.beans.Items;
import com.cg.onlinetokarysystem.beans.Transaction;

public class MainClass {

	public static void main(String[] args) {
		Customer customer= customerSearch();
		if(customer!=null)
			System.out.println("Details Found");
		else
			System.out.println("No Details Found");

	}
	public static Customer customerSearch() {
		Customer customerList[]=new Customer[4];
		customerList[0]=new Customer("abhi", "c", "+919638527410", 12345, new DeliveryAddress("pune", "mhr", "india", 500010),new Items("carrot", "available", 1, 60),new Bill(1, 10, 80, 12, 12, 5),new Delivery("26/03/2018", "successful"),new Discount("half", "27/03/2018", "halfd", 10),new Transaction("cash", "successful", "26/03/2018", 70));
		customerList[1]=new Customer("yosh", "a", "+919638527411", 12348, new DeliveryAddress("pune", "mhr", "india", 500010),new Items("raddish", "available", 1, 60),new Bill(1, 10, 80, 12, 12, 5),new Delivery("27/03/2018", "successful"),new Discount("half", "28/03/2018", "halfd", 10),new Transaction("cash", "successful", "27/03/2018", 70));
		customerList[2]=new Customer("satish", "mahajan", "+919638527412", 12349, new DeliveryAddress("pune", "mhr", "india", 500010),new Items("brinjal", "available", 1, 60),new Bill(1, 10, 80, 12, 12, 5),new Delivery("28/03/2018", "successful"),new Discount("half", "29/03/2018", "halfd", 10),new Transaction("cash", "successful", "28/03/2018", 70));
		for(Customer customer:customerList) {
			if(customer!=null&&customer.getDelivery().getDateOfDelivery()=="27/03/2018")
				return customer;
			
		}
		return null;
}
}
