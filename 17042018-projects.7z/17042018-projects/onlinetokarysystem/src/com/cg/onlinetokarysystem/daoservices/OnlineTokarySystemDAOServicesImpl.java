package com.cg.onlinetokarysystem.daoservices;

public class OnlineTokarySystemDAOServicesImpl {

}
