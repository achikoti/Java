package com.cg.onlinetokarysystem.services;

public class OnlineTokarySystemServicesImpl {

}
